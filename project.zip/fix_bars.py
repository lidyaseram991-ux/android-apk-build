import os

files = [
    "app/src/main/java/com/example/ui/AddExpenseScreen.kt",
    "app/src/main/java/com/example/ui/HistoryScreen.kt",
    "app/src/main/java/com/example/ui/ReportsScreen.kt",
    "app/src/main/java/com/example/ui/BudgetConfigScreen.kt",
    "app/src/main/java/com/example/ui/DashboardScreen.kt"
]

for file_path in files:
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check if TopAppBar colors is already set
    if 'TopAppBarDefaults.topAppBarColors' not in content:
        content = content.replace(
            'TopAppBar(',
            'TopAppBar(\n                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),'
        )
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)

# Now fix NavigationBar in Navigation.kt
nav_path = "app/src/main/java/com/example/ui/Navigation.kt"
with open(nav_path, 'r', encoding='utf-8') as f:
    nav_content = f.read()

nav_content = nav_content.replace(
    'NavigationBar(\n                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f)',
    'NavigationBar(\n                        containerColor = androidx.compose.ui.graphics.Color.Transparent'
)
# Make sure we don't have double Transparent replacements
with open(nav_path, 'w', encoding='utf-8') as f:
    f.write(nav_content)

print("Bars fixed.")
