import os

file_path = "app/src/main/java/com/example/ui/HistoryScreen.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

content = content.replace(
    'var selectedCategoryFilter by remember { mutableStateOf("الكل") }',
    'val initialAll = string("all")\n    var selectedCategoryFilter by remember { mutableStateOf(initialAll) }'
)
content = content.replace(
    'val categories = listOf("الكل", string("cat_food")',
    'val categories = listOf(string("all"), string("cat_food")'
)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed history.")
