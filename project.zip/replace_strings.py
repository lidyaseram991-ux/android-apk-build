import os
import re

files_to_edit = [
    "app/src/main/java/com/example/ui/DashboardScreen.kt",
    "app/src/main/java/com/example/ui/AddExpenseScreen.kt",
    "app/src/main/java/com/example/ui/HistoryScreen.kt",
    "app/src/main/java/com/example/ui/BudgetConfigScreen.kt"
]

replacements = {
    '"لوحة التحكم"': 'string("dashboard_title")',
    '"إضافة مصروف جديد"': 'string("add_expense_title")',
    '"سجل المصاريف"': 'string("history_title")',
    '"إعدادات الميزانية والتطبيق"': 'string("settings_title")',
    '"المبلغ المتبقي"': 'string("remaining_balance")',
    '"الميزانية الأصلية"': 'string("original_budget")',
    '"إجمالي المصاريف"': 'string("total_expenses")',
    '"تحليل معدل الاستهلاك"': 'string("consumption_analysis")',
    '"معدل الحرق اليومي: "': 'string("daily_burn_rate") + ": "',
    '"معدل الحرق الأسبوعي: "': 'string("weekly_burn_rate") + ": "',
    '"أيام"': 'string("runway_days")',
    '"أسابيع"': 'string("runway_weeks")',
    '"أشهر"': 'string("runway_months")',
    '"الحد اليومي المقترح للإنفاق (لنهاية الشهر):"': 'string("recommended_daily_limit")',
    '"المصاريف الأخيرة"': 'string("recent_expenses")',
    '"عرض السجل كاملاً"': 'string("view_all_history")',
    '"مصروف"': 'string("expense")',
    '"إضافة رصيد (دخل)"': 'string("income")',
    '"إضافة رصيد"': 'string("income")',
    '"اسم المنتج"': 'string("product_name")',
    '"المصدر / الوصف"': 'string("source_desc")',
    '"المبلغ (مثال: 1000)"': 'string("amount_example")',
    '"تاريخ الشراء"': 'string("purchase_date")',
    '"وقت الشراء"': 'string("purchase_time")',
    '"تأكيد"': 'string("confirm")',
    '"إلغاء"': 'string("cancel")',
    '"حفظ المصروف"': 'string("save_expense")',
    '"إضافة الرصيد"': 'string("save_income")',
    '"لا توجد مصاريف بعد."': 'string("no_expenses_yet")',
    '"المبلغ الكلي المتاح"': 'string("total_available")',
    '"حفظ الميزانية"': 'string("save_budget")',
    '"مظهر التطبيق"': 'string("app_appearance")',
    '"اختر السمة"': 'string("choose_theme")',
    '"رفع صورة خلفية من الهاتف"': 'string("upload_bg")',
    '"تطوير: مصطفى عمر"': 'string("dev_name")',
    '"طعام"': 'string("cat_food")',
    '"تسوق"': 'string("cat_shopping")',
    '"فواتير"': 'string("cat_bills")',
    '"تقنية"': 'string("cat_tech")',
    '"أخرى"': 'string("cat_other")',
    '"راتب"': 'string("cat_salary")',
    '"مكافأة"': 'string("cat_bonus")',
    '"تحويل"': 'string("cat_transfer")',
    '"إضافة رصيد للميزانية"': 'string("add_funds_title")',
    '"إضافة"': 'string("add")',
    '"حذف"': 'string("delete")',
    '"رجوع"': 'string("back")'
}

for file_path in files_to_edit:
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    for ar_str, en_call in replacements.items():
        content = content.replace(ar_str, en_call)
        
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)

print("Done replacing.")
