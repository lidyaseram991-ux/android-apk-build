import os

file_path = "app/src/main/java/com/example/ui/BudgetViewModel.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

content = content.replace(
    'context.packageName + ".provider"',
    'context.packageName + ".fileprovider"'
)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Updated authority.")
