import os

file_path = "app/src/main/java/com/example/ui/Navigation.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Add REPORTS to Routes
content = content.replace(
    'const val BUDGET_CONFIG = "budget_config"',
    'const val BUDGET_CONFIG = "budget_config"\n    const val REPORTS = "reports"'
)

# 2. Add imports
imports_to_add = """
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.unit.dp
"""
content = content.replace(
    'import java.io.File',
    'import java.io.File' + imports_to_add
)

# 3. Add bottom bar logic inside Box
old_navhost = """        NavHost(navController = navController, startDestination = Routes.DASHBOARD) {
            composable(Routes.DASHBOARD) {
                DashboardScreen(navController = navController, viewModel = budgetViewModel)
            }
            composable(Routes.ADD_EXPENSE) {
                AddExpenseScreen(navController = navController, viewModel = budgetViewModel)
            }
            composable(Routes.HISTORY) {
                HistoryScreen(navController = navController, viewModel = budgetViewModel)
            }
            composable(Routes.BUDGET_CONFIG) {
                BudgetConfigScreen(navController = navController, viewModel = budgetViewModel)
            }
        }"""

new_navhost = """        val navBackStackEntry by navController.currentBackStackEntryAsState()
        val currentRoute = navBackStackEntry?.destination?.route
        val mainRoutes = listOf(Routes.DASHBOARD, Routes.REPORTS, Routes.HISTORY, Routes.BUDGET_CONFIG)
        val showBottomBar = currentRoute in mainRoutes

        Scaffold(
            containerColor = androidx.compose.ui.graphics.Color.Transparent,
            bottomBar = {
                if (showBottomBar) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f)
                    ) {
                        NavigationBarItem(
                            icon = { Icon(Icons.Default.Home, contentDescription = string("home")) },
                            label = { Text(string("home")) },
                            selected = currentRoute == Routes.DASHBOARD,
                            onClick = {
                                if (currentRoute != Routes.DASHBOARD) {
                                    navController.navigate(Routes.DASHBOARD) {
                                        popUpTo(Routes.DASHBOARD) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            }
                        )
                        NavigationBarItem(
                            icon = { Icon(Icons.Default.BarChart, contentDescription = string("reports_title")) },
                            label = { Text(string("reports_title")) },
                            selected = currentRoute == Routes.REPORTS,
                            onClick = {
                                if (currentRoute != Routes.REPORTS) {
                                    navController.navigate(Routes.REPORTS) {
                                        popUpTo(Routes.DASHBOARD) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            }
                        )
                        Box(modifier = Modifier.weight(1f), contentAlignment = androidx.compose.ui.Alignment.Center) {
                            FloatingActionButton(
                                onClick = { navController.navigate(Routes.ADD_EXPENSE) },
                                shape = CircleShape,
                                containerColor = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.offset(y = (-16).dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = string("add_expense_title"), tint = MaterialTheme.colorScheme.onPrimary)
                            }
                        }
                        NavigationBarItem(
                            icon = { Icon(Icons.Default.List, contentDescription = string("history_title")) },
                            label = { Text(string("history_title")) },
                            selected = currentRoute == Routes.HISTORY,
                            onClick = {
                                if (currentRoute != Routes.HISTORY) {
                                    navController.navigate(Routes.HISTORY) {
                                        popUpTo(Routes.DASHBOARD) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            }
                        )
                        NavigationBarItem(
                            icon = { Icon(Icons.Default.Settings, contentDescription = string("settings_title")) },
                            label = { Text(string("settings_title")) },
                            selected = currentRoute == Routes.BUDGET_CONFIG,
                            onClick = {
                                if (currentRoute != Routes.BUDGET_CONFIG) {
                                    navController.navigate(Routes.BUDGET_CONFIG) {
                                        popUpTo(Routes.DASHBOARD) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            }
                        )
                    }
                }
            }
        ) { paddingValues ->
            NavHost(
                navController = navController, 
                startDestination = Routes.DASHBOARD,
                modifier = Modifier.padding(paddingValues)
            ) {
                composable(Routes.DASHBOARD) {
                    DashboardScreen(navController = navController, viewModel = budgetViewModel)
                }
                composable(Routes.ADD_EXPENSE) {
                    AddExpenseScreen(navController = navController, viewModel = budgetViewModel)
                }
                composable(Routes.HISTORY) {
                    HistoryScreen(navController = navController, viewModel = budgetViewModel)
                }
                composable(Routes.BUDGET_CONFIG) {
                    BudgetConfigScreen(navController = navController, viewModel = budgetViewModel)
                }
                composable(Routes.REPORTS) {
                    ReportsScreen(navController = navController, viewModel = budgetViewModel)
                }
            }
        }"""

content = content.replace(old_navhost, new_navhost)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Navigation updated.")
