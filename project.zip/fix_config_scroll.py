import os

file_path = "app/src/main/java/com/example/ui/BudgetConfigScreen.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

content = content.replace(
    'import androidx.compose.foundation.layout.*',
    'import androidx.compose.foundation.layout.*\nimport androidx.compose.foundation.rememberScrollState\nimport androidx.compose.foundation.verticalScroll'
)

content = content.replace(
    '''        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),''',
    '''        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),'''
)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed scrolling.")
