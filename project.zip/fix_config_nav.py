import os

file_path = "app/src/main/java/com/example/ui/BudgetConfigScreen.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

back_button_block = """                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = string("back"))
                    }
                }"""
content = content.replace(back_button_block, "")

back_button_block2 = """                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = string("back"))
                    }
                }"""
content = content.replace(back_button_block2, "")

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Config nav cleaned.")
