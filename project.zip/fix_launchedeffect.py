import os

file_path = "app/src/main/java/com/example/ui/DashboardScreen.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

content = content.replace(
    'import androidx.compose.runtime.mutableStateOf',
    'import androidx.compose.runtime.mutableStateOf\nimport androidx.compose.runtime.LaunchedEffect'
)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed LaunchedEffect.")
