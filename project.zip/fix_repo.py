import os

file_path = "app/src/main/java/com/example/data/BudgetRepository.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

content = content.replace(
    'suspend fun deleteExpenseById(id: Int) {\n        expensesDao.deleteExpenseById(id)\n    }',
    'suspend fun deleteExpenseById(id: Int) {\n        expensesDao.deleteExpenseById(id)\n    }\n\n    suspend fun deleteAllExpenses() {\n        expensesDao.deleteAllExpenses()\n    }'
)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Updated Repo.")
