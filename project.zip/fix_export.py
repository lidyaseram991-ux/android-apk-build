import os

file_path = "app/src/main/java/com/example/ui/HistoryScreen.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

import_str = """
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileWriter
"""
content = content.replace('import androidx.navigation.NavController', 'import androidx.navigation.NavController\n' + import_str)

old_export = """fun exportToCsv(context: Context, expenses: List<ExpenseEntity>) {
    val csvHeader = "اسم المنتج,السعر,تاريخ الشراء,وقت الشراء,الفئة\\n"
    val csvData = expenses.joinToString(separator = "\\n") { expense ->
        "${expense.name},${expense.price},${expense.date},${expense.time},${expense.category}"
    }
    val csvContent = csvHeader + csvData

    val sendIntent: Intent = Intent().apply {
        action = Intent.ACTION_SEND
        putExtra(Intent.EXTRA_TEXT, csvContent)
        type = "text/csv"
    }
    val shareIntent = Intent.createChooser(sendIntent, "تصدير السجل (CSV)")
    context.startActivity(shareIntent)
}"""

new_export = """fun exportToCsv(context: Context, expenses: List<ExpenseEntity>) {
    try {
        val csvHeader = "اسم المنتج,السعر,تاريخ الشراء,وقت الشراء,الفئة\\n"
        val csvData = expenses.joinToString(separator = "\\n") { expense ->
            "${expense.name},${expense.price},${expense.date},${expense.time},${expense.category}"
        }
        val csvContent = csvHeader + csvData

        val file = File(context.cacheDir, "budget_history.csv")
        FileWriter(file).use { it.write(csvContent) }

        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

        val sendIntent: Intent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_STREAM, uri)
            type = "text/csv"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val shareIntent = Intent.createChooser(sendIntent, "تصدير السجل (CSV)")
        shareIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(shareIntent)
    } catch (e: Exception) {
        e.printStackTrace()
    }
}"""

content = content.replace(old_export, new_export)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed export.")
