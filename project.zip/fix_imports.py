import os

file_path = "app/src/main/java/com/example/ui/DashboardScreen.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

if 'import androidx.compose.runtime.LaunchedEffect' not in content:
    content = content.replace(
        'import androidx.compose.runtime.*',
        'import androidx.compose.runtime.*\nimport androidx.compose.runtime.LaunchedEffect'
    )

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed imports.")
