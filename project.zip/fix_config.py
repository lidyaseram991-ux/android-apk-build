import os

file_path = "app/src/main/java/com/example/ui/BudgetConfigScreen.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

card_to_add = """
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f))
            ) {
                Column(modifier = Modifier.padding(16.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text(
                        text = string("budget_period"),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    
                    var daysStr by remember { mutableStateOf(uiState.daysLeftInMonth.toString()) }
                    
                    OutlinedTextField(
                        value = daysStr,
                        onValueChange = { daysStr = it },
                        label = { Text(string("days_remaining_setup")) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth().testTag("days_input"),
                        singleLine = true
                    )
                    
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                val days = daysStr.toIntOrNull() ?: 0
                                if (days > 0) {
                                    viewModel.setCustomDaysRemaining(days)
                                    navController.navigateUp()
                                }
                            },
                            modifier = Modifier.weight(1f).testTag("save_days_button"),
                            enabled = (daysStr.toIntOrNull() ?: 0) > 0
                        ) {
                            Text(string("set_days"))
                        }
                        
                        OutlinedButton(
                            onClick = {
                                viewModel.setCustomDaysRemaining(0)
                                navController.navigateUp()
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(string("reset_days"))
                        }
                    }
                }
            }
"""

content = content.replace(
    'Card(\n                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f))\n            ) {\n                Column(modifier = Modifier.padding(16.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {\n                    Text(\n                        text = string("app_appearance"),',
    card_to_add + '\n            Card(\n                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f))\n            ) {\n                Column(modifier = Modifier.padding(16.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {\n                    Text(\n                        text = string("app_appearance"),'
)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed config.")
