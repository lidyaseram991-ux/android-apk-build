import os

file_path = "app/src/main/java/com/example/ui/DashboardScreen.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Add imports for Close icon
if 'import androidx.compose.material.icons.filled.Close' not in content:
    content = content.replace(
        'import androidx.compose.material.icons.filled.Add',
        'import androidx.compose.material.icons.filled.Add\nimport androidx.compose.material.icons.filled.Close'
    )

# Add alertDismissed state
content = content.replace(
    'val uiState by viewModel.uiState.collectAsStateWithLifecycle()\n    var showAddFundsDialog by remember { mutableStateOf(false) }',
    'val uiState by viewModel.uiState.collectAsStateWithLifecycle()\n    var showAddFundsDialog by remember { mutableStateOf(false) }\n    var alertDismissed by remember { mutableStateOf(false) }\n    LaunchedEffect(uiState.remainingBalance) { alertDismissed = false }'
)

# Update AlertBanner usage
content = content.replace(
    '''            if (uiState.isWarning || uiState.isCritical) {
                item {
                    AlertBanner(isCritical = uiState.isCritical)
                }
            }''',
    '''            if ((uiState.isWarning || uiState.isCritical) && !alertDismissed) {
                item {
                    AlertBanner(isCritical = uiState.isCritical, onDismiss = { alertDismissed = true })
                }
            }'''
)

# Update AlertBanner definition
old_alert_banner = '''@Composable
fun AlertBanner(isCritical: Boolean) {
    val containerColor = if (isCritical) MaterialTheme.colorScheme.errorContainer else Color(0xFFFFE082) // Amber
    val contentColor = if (isCritical) MaterialTheme.colorScheme.onErrorContainer else Color(0xFF5D4037)

    Card(
        colors = CardDefaults.cardColors(containerColor = containerColor.copy(alpha = 0.9f), contentColor = contentColor),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Warning, contentDescription = "تحذير", modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(
                    text = if (isCritical) "حالة حرجة!" else "تحذير!",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isCritical) "رصيدك أقل من 20% أو يكفيك لأقل من 5 أيام." else "رصيدك أقل من 50% من الميزانية.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}'''

new_alert_banner = '''@Composable
fun AlertBanner(isCritical: Boolean, onDismiss: () -> Unit) {
    val containerColor = if (isCritical) MaterialTheme.colorScheme.errorContainer else Color(0xFFFFE082) // Amber
    val contentColor = if (isCritical) MaterialTheme.colorScheme.onErrorContainer else Color(0xFF5D4037)

    Card(
        colors = CardDefaults.cardColors(containerColor = containerColor.copy(alpha = 0.9f), contentColor = contentColor),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Warning, contentDescription = "تحذير", modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (isCritical) "حالة حرجة!" else "تحذير!",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isCritical) "رصيدك أقل من 20% أو يكفيك لأقل من 5 أيام." else "رصيدك أقل من 50% من الميزانية.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            IconButton(onClick = onDismiss) {
                Icon(Icons.Default.Close, contentDescription = "إغلاق")
            }
        }
    }
}'''

content = content.replace(old_alert_banner, new_alert_banner)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed dashboard alert.")
