import os

file_path = "app/src/main/java/com/example/ui/ReportsScreen.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

content = content.replace(
    'useCenter = false,',
    'useCenter = false,\n                            topLeft = Offset(40f, 40f),\n                            size = Size(size.width - 80f, size.height - 80f),'
)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed drawArc.")
