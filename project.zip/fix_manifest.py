import os

file_path = "app/src/main/AndroidManifest.xml"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

provider_xml = """
        <provider
            android:name="androidx.core.content.FileProvider"
            android:authorities="${applicationId}.fileprovider"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data
                android:name="android.support.FILE_PROVIDER_PATHS"
                android:resource="@xml/file_paths" />
        </provider>
"""

content = content.replace(
    '</application>',
    provider_xml + '    </application>'
)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed manifest.")
