import os

file_path = "app/src/main/java/com/example/ui/BudgetConfigScreen.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

import_launcher_code = """    val jsonPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent(),
        onResult = { uri ->
            uri?.let {
                viewModel.importBackup(context, it)
            }
        }
    )

    Scaffold("""

content = content.replace('    Scaffold(', import_launcher_code)

backup_card = """            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = string("backup_data") + " / " + string("import_data"),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = string("backup_desc"),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.exportBackup(context) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(string("backup_data"))
                        }
                        OutlinedButton(
                            onClick = { jsonPickerLauncher.launch("application/json") },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(string("import_data"))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))"""

content = content.replace('            Spacer(modifier = Modifier.weight(1f))', backup_card)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Updated BudgetConfigScreen.")
