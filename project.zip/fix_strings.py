import os

file_path = "app/src/main/java/com/example/ui/AppStrings.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

en_adds = """
        "backup_data" to "Backup Data",
        "import_data" to "Import Data",
        "backup_desc" to "Export/Import a backup to share data with another Masroofi app.",
"""
content = content.replace(
    '"close" to "Close",',
    '"close" to "Close",' + en_adds
)

ar_adds = """
        "backup_data" to "نسخ احتياطي (تصدير)",
        "import_data" to "استيراد بيانات",
        "backup_desc" to "تصدير/استيراد نسخة احتياطية لمشاركة البيانات مع تطبيق مصروفي آخر.",
"""
content = content.replace(
    '"close" to "إغلاق",',
    '"close" to "إغلاق",' + ar_adds
)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Updated AppStrings.")
