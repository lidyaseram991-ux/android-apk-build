import os
import re

files_to_edit = [
    "app/src/main/java/com/example/ui/AddExpenseScreen.kt",
    "app/src/main/java/com/example/ui/HistoryScreen.kt",
    "app/src/main/java/com/example/ui/BudgetConfigScreen.kt"
]

def fix_add_expense(content):
    content = content.replace(
        'var selectedCategory by remember { mutableStateOf(string("cat_other")) }',
        'val initialCategory = string("cat_other")\n    var selectedCategory by remember { mutableStateOf(initialCategory) }'
    )
    return content

for file_path in files_to_edit:
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    if "AddExpenseScreen" in file_path:
        content = fix_add_expense(content)
        
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)

print("Done fixing.")
