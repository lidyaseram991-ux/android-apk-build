import os

file_path = "app/src/main/java/com/example/ui/AppStrings.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

en_adds = """        "reports_title" to "Reports",
        "period_today" to "Today",
        "period_week" to "This Week",
        "period_month" to "This Month",
        "period_year" to "This Year",
        "highest_spending_day" to "Highest Day",
        "daily_average" to "Daily Avg",
        "transactions_count" to "Transactions",
        "most_spent_categories" to "Top Categories",
        "total_expenses_chart" to "Total Expenses",
        "currency" to "د.ل",
        "home" to "Home",
"""
content = content.replace(
    '"close" to "Close"\n    )',
    '"close" to "Close",\n' + en_adds + '    )'
)

ar_adds = """        "reports_title" to "التقارير",
        "period_today" to "اليوم",
        "period_week" to "هذا الأسبوع",
        "period_month" to "هذا الشهر",
        "period_year" to "هذه السنة",
        "highest_spending_day" to "أعلى يوم إنفاق",
        "daily_average" to "متوسط المصروف اليومي",
        "transactions_count" to "عدد المصروفات",
        "most_spent_categories" to "أكثر الفئات إنفاقًا",
        "total_expenses_chart" to "إجمالي المصروفات",
        "currency" to "د.ل",
        "home" to "الرئيسية",
"""
content = content.replace(
    '"close" to "إغلاق"\n    )',
    '"close" to "إغلاق",\n' + ar_adds + '    )'
)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Updated AppStrings for reports.")
