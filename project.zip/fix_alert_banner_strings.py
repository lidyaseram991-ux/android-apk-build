import os

file_path = "app/src/main/java/com/example/ui/DashboardScreen.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

content = content.replace(
    'text = if (isCritical) "حالة حرجة!" else "تحذير!",',
    'text = if (isCritical) string("critical_title") else string("warning_title"),'
)
content = content.replace(
    'text = if (isCritical) "رصيدك أقل من 20% أو يكفيك لأقل من 5 أيام." else "رصيدك أقل من 50% من الميزانية.",',
    'text = if (isCritical) string("critical_desc") else string("warning_desc"),'
)
content = content.replace(
    'Icon(Icons.Default.Close, contentDescription = "إغلاق")',
    'Icon(Icons.Default.Close, contentDescription = string("close"))'
)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed alert banner strings.")
