import os

file_path = "app/src/main/java/com/example/ui/BudgetViewModel.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Add _customEndDate
content = content.replace(
    'private val _isEnglish = MutableStateFlow(sharedPrefs.getBoolean("is_english", false))',
    'private val _isEnglish = MutableStateFlow(sharedPrefs.getBoolean("is_english", false))\n    private val _customEndDate = MutableStateFlow(sharedPrefs.getLong("budget_end_date", 0L))'
)

# Update combine
content = content.replace(
    'combine(_expensesFlow, _budgetFlow, _appTheme, _isEnglish) { expenses, budget, theme, isEn ->',
    'combine(_expensesFlow, _budgetFlow, _appTheme, _isEnglish, _customEndDate) { expenses, budget, theme, isEn, customEnd ->'
)
content = content.replace(
    'calculateUiState(expenses, budget, theme, isEn)',
    'calculateUiState(expenses, budget, theme, isEn, customEnd)'
)

# Update calculateUiState signature
content = content.replace(
    'calculateUiState(expenses: List<ExpenseEntity>, budget: BudgetEntity?, theme: String, isEnglish: Boolean): BudgetUiState {',
    'calculateUiState(expenses: List<ExpenseEntity>, budget: BudgetEntity?, theme: String, isEnglish: Boolean, customEnd: Long): BudgetUiState {'
)

# Update daysLeftInMonth calculation
old_calc = """        val yearMonth = YearMonth.from(today)
        val lastDayOfMonth = yearMonth.atEndOfMonth()
        var daysLeftInMonth = ChronoUnit.DAYS.between(today, lastDayOfMonth)
        if (daysLeftInMonth <= 0) daysLeftInMonth = 1"""

new_calc = """        val endDate = if (customEnd > 0L) {
            val customDate = LocalDate.ofEpochDay(customEnd)
            if (customDate.isBefore(today)) today.plusDays(1) else customDate
        } else {
            YearMonth.from(today).atEndOfMonth()
        }
        var daysLeftInMonth = ChronoUnit.DAYS.between(today, endDate)
        if (daysLeftInMonth <= 0) daysLeftInMonth = 1"""

content = content.replace(old_calc, new_calc)

# Add setCustomDaysRemaining
content = content.replace(
    'fun toggleLanguage() {',
    '''fun setCustomDaysRemaining(days: Int) {
        val newEndDate = LocalDate.now().plusDays(days.toLong())
        val epochDays = newEndDate.toEpochDay()
        sharedPrefs.edit().putLong("budget_end_date", epochDays).apply()
        _customEndDate.value = epochDays
    }
    
    fun toggleLanguage() {'''
)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed viewmodel.")
