import os

file_path = "app/src/main/java/com/example/MainActivity.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

new_enable = """    enableEdgeToEdge(
        statusBarStyle = androidx.activity.SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT),
        navigationBarStyle = androidx.activity.SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
    )"""

content = content.replace("    enableEdgeToEdge()", new_enable)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed MainActivity.")
