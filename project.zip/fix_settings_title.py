import os

file_path = "app/src/main/java/com/example/ui/AppStrings.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

content = content.replace(
    '"settings_title" to "Settings & Budget",',
    '"settings_title" to "Budget",'
)

content = content.replace(
    '"settings_title" to "إعدادات الميزانية والتطبيق",',
    '"settings_title" to "الميزانية",'
)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed settings title.")
