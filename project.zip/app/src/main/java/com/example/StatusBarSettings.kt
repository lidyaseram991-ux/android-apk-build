package com.example

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

enum class BatteryStyle { DEFAULT, PORTRAIT, CIRCLE, TEXT_ONLY }

data class StatusBarState(
    val batteryPercentage: Int = 51,
    val backgroundColor: Long = 0xFF1E1E24,
    val isPercentageInside: Boolean = true,
    val showBluetooth: Boolean = false,
    val showWifi: Boolean = false,
    val showAlarm: Boolean = false,
    val networkStrength: Int = 4,
    val networkType: String = "4G",
    val backgroundAlpha: Float = 1f,
    val isAutoCharging: Boolean = false,
    val autoChargeIntervalSeconds: Int = 5,
    val isOverlayVisible: Boolean = true,
    val language: String = "ar", // Default to Arabic
    val batteryStyle: BatteryStyle = BatteryStyle.DEFAULT,
    val isBatteryOnRight: Boolean = false,
    val notificationBitmaps: List<android.graphics.Bitmap> = emptyList()
)

object StatusBarSettings {
    private val _settingsFlow = MutableStateFlow(StatusBarState())
    val settingsFlow: StateFlow<StatusBarState> = _settingsFlow
    
    var isAccessibilityServiceRunning = false
    
    private val scope = CoroutineScope(Dispatchers.Main)
    private var autoChargeJob: Job? = null
    
    fun updateBattery(percentage: Int) {
        _settingsFlow.value = _settingsFlow.value.copy(batteryPercentage = percentage)
    }
    
    fun updateBackgroundColor(color: Long) {
        _settingsFlow.value = _settingsFlow.value.copy(backgroundColor = color)
    }

    fun updatePercentageInside(isInside: Boolean) {
        _settingsFlow.value = _settingsFlow.value.copy(isPercentageInside = isInside)
    }

    fun updateBatteryPosition(isRight: Boolean) {
        _settingsFlow.value = _settingsFlow.value.copy(isBatteryOnRight = isRight)
    }
    
    fun updateNotificationIcons(bitmaps: List<android.graphics.Bitmap>) {
        _settingsFlow.value = _settingsFlow.value.copy(notificationBitmaps = bitmaps)
    }
    
    fun updateToggles(bluetooth: Boolean? = null, wifi: Boolean? = null, alarm: Boolean? = null) {
        var state = _settingsFlow.value
        bluetooth?.let { state = state.copy(showBluetooth = it) }
        wifi?.let { state = state.copy(showWifi = it) }
        alarm?.let { state = state.copy(showAlarm = it) }
        _settingsFlow.value = state
    }
    
    fun updateNetwork(strength: Int? = null, type: String? = null) {
        var state = _settingsFlow.value
        strength?.let { state = state.copy(networkStrength = it) }
        type?.let { state = state.copy(networkType = it) }
        _settingsFlow.value = state
    }
    
    fun updateBackgroundAlpha(alpha: Float) {
        _settingsFlow.value = _settingsFlow.value.copy(backgroundAlpha = alpha)
    }
    
    fun updateAutoChargeInterval(seconds: Int) {
        _settingsFlow.value = _settingsFlow.value.copy(autoChargeIntervalSeconds = seconds)
        if (_settingsFlow.value.isAutoCharging) {
            startAutoCharging() // Restart with new interval
        }
    }
    
    fun toggleAutoCharging(isCharging: Boolean) {
        _settingsFlow.value = _settingsFlow.value.copy(isAutoCharging = isCharging)
        if (isCharging) {
            startAutoCharging()
        } else {
            autoChargeJob?.cancel()
        }
    }
    
    fun toggleOverlay(isVisible: Boolean) {
        _settingsFlow.value = _settingsFlow.value.copy(isOverlayVisible = isVisible)
    }

    fun toggleLanguage() {
        val newLang = if (_settingsFlow.value.language == "ar") "en" else "ar"
        _settingsFlow.value = _settingsFlow.value.copy(language = newLang)
    }

    fun updateBatteryStyle(style: BatteryStyle) {
        _settingsFlow.value = _settingsFlow.value.copy(batteryStyle = style)
    }

    private fun startAutoCharging() {
        autoChargeJob?.cancel()
        autoChargeJob = scope.launch {
            while (_settingsFlow.value.isAutoCharging) {
                delay(_settingsFlow.value.autoChargeIntervalSeconds * 1000L)
                val currentBattery = _settingsFlow.value.batteryPercentage
                if (currentBattery < 100) {
                    _settingsFlow.value = _settingsFlow.value.copy(batteryPercentage = currentBattery + 1)
                } else {
                    _settingsFlow.value = _settingsFlow.value.copy(isAutoCharging = false)
                    break
                }
            }
        }
    }
}
