package com.example.data

import kotlinx.coroutines.flow.Flow

class BudgetRepository(
    private val expensesDao: ExpensesDao,
    private val budgetDao: BudgetDao
) {
    val allExpenses: Flow<List<ExpenseEntity>> = expensesDao.getAllExpenses()
    val currentBudget: Flow<BudgetEntity?> = budgetDao.getBudget()

    suspend fun insertExpense(expense: ExpenseEntity) {
        expensesDao.insertExpense(expense)
    }

    suspend fun deleteExpenseById(id: Int) {
        expensesDao.deleteExpenseById(id)
    }

    suspend fun updateBudget(amount: Double) {
        budgetDao.updateBudget(BudgetEntity(id = 1, initialBudget = amount))
    }
}
