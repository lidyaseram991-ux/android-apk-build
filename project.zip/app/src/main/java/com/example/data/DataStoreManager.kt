package com.example.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore by preferencesDataStore(name = "settings")

class DataStoreManager(private val context: Context) {

    companion object {
        val PAT_KEY = stringPreferencesKey("github_pat")
        val OWNER_KEY = stringPreferencesKey("github_owner")
        val REPO_KEY = stringPreferencesKey("github_repo")
    }

    val patFlow: Flow<String?> = context.dataStore.data.map { it[PAT_KEY] }
    val ownerFlow: Flow<String?> = context.dataStore.data.map { it[OWNER_KEY] }
    val repoFlow: Flow<String?> = context.dataStore.data.map { it[REPO_KEY] }

    suspend fun saveConfig(pat: String, owner: String, repo: String) {
        context.dataStore.edit { prefs ->
            prefs[PAT_KEY] = pat
            prefs[OWNER_KEY] = owner
            prefs[REPO_KEY] = repo
        }
    }
}
