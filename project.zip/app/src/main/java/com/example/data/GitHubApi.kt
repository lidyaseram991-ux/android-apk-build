package com.example.data

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Url

@JsonClass(generateAdapter = true)
data class GithubContentRequest(
    val message: String,
    val content: String,
    val sha: String? = null
)

@JsonClass(generateAdapter = true)
data class GithubContentResponse(
    val content: ContentInfo
)

@JsonClass(generateAdapter = true)
data class ContentInfo(
    val sha: String,
    val path: String
)

@JsonClass(generateAdapter = true)
data class GithubRunList(
    val total_count: Int,
    @Json(name = "workflow_runs") val workflowRuns: List<GithubRun>
)

@JsonClass(generateAdapter = true)
data class GithubRun(
    val id: Long,
    val status: String?,
    val conclusion: String?,
    val head_commit: HeadCommit?
)

@JsonClass(generateAdapter = true)
data class HeadCommit(
    val message: String?
)

@JsonClass(generateAdapter = true)
data class GithubArtifactList(
    val total_count: Int,
    val artifacts: List<GithubArtifact>
)

@JsonClass(generateAdapter = true)
data class GithubArtifact(
    val id: Long,
    val name: String,
    val archive_download_url: String
)

@JsonClass(generateAdapter = true)
data class GithubRepo(
    val id: Long,
    val name: String,
    val full_name: String,
    val private: Boolean,
    val owner: GithubOwner
)

@JsonClass(generateAdapter = true)
data class GithubOwner(
    val login: String
)

@JsonClass(generateAdapter = true)
data class CreateRepoRequest(
    val name: String,
    val description: String = "",
    val private: Boolean = true
)

interface GitHubApi {

    @GET("user/repos")
    suspend fun getUserRepos(
        @Header("Authorization") auth: String,
        @retrofit2.http.Query("sort") sort: String = "updated",
        @retrofit2.http.Query("per_page") perPage: Int = 100
    ): Response<List<GithubRepo>>

    @retrofit2.http.POST("user/repos")
    suspend fun createRepo(
        @Header("Authorization") auth: String,
        @Body request: CreateRepoRequest
    ): Response<GithubRepo>

    @GET("repos/{owner}/{repo}/contents/{path}")
    suspend fun getFileContent(
        @Header("Authorization") auth: String,
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Path("path") path: String
    ): Response<GithubContentResponse>

    @PUT("repos/{owner}/{repo}/contents/{path}")
    suspend fun updateFileContent(
        @Header("Authorization") auth: String,
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Path("path") path: String,
        @Body body: GithubContentRequest
    ): Response<GithubContentResponse>

    @GET("repos/{owner}/{repo}/actions/runs")
    suspend fun getWorkflowRuns(
        @Header("Authorization") auth: String,
        @Path("owner") owner: String,
        @Path("repo") repo: String
    ): Response<GithubRunList>

    @GET("repos/{owner}/{repo}/actions/runs/{run_id}/logs")
    suspend fun getWorkflowRunLogs(
        @Header("Authorization") auth: String,
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Path("run_id") runId: Long
    ): Response<ResponseBody>

    @GET("repos/{owner}/{repo}/actions/runs/{run_id}/artifacts")
    suspend fun getWorkflowRunArtifacts(
        @Header("Authorization") auth: String,
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Path("run_id") runId: Long
    ): Response<GithubArtifactList>
    
    @GET
    suspend fun downloadArtifact(
        @Header("Authorization") auth: String,
        @Url url: String
    ): Response<ResponseBody>
}
