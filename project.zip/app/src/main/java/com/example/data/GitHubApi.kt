package com.example.data

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Url

@JsonClass(generateAdapter = true)
data class GithubContentRequest(
    val message: String,
    val content: String,
    val sha: String? = null
)

@JsonClass(generateAdapter = true)
data class GithubContentResponse(
    val content: ContentInfo
)

@JsonClass(generateAdapter = true)
data class ContentInfo(
    val sha: String,
    val path: String
)

@JsonClass(generateAdapter = true)
data class GithubRunList(
    val total_count: Int,
    @Json(name = "workflow_runs") val workflowRuns: List<GithubRun>
)

@JsonClass(generateAdapter = true)
data class GithubRun(
    val id: Long,
    val status: String?,
    val conclusion: String?,
    val head_commit: HeadCommit?
)

@JsonClass(generateAdapter = true)
data class HeadCommit(
    val message: String?
)

@JsonClass(generateAdapter = true)
data class GithubArtifactList(
    val total_count: Int,
    val artifacts: List<GithubArtifact>
)

@JsonClass(generateAdapter = true)
data class GithubArtifact(
    val id: Long,
    val name: String,
    val archive_download_url: String
)

interface GitHubApi {

    @GET("repos/{owner}/{repo}/contents/{path}")
    suspend fun getFileContent(
        @Header("Authorization") auth: String,
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Path("path") path: String
    ): Response<GithubContentResponse>

    @PUT("repos/{owner}/{repo}/contents/{path}")
    suspend fun updateFileContent(
        @Header("Authorization") auth: String,
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Path("path") path: String,
        @Body body: GithubContentRequest
    ): Response<GithubContentResponse>

    @GET("repos/{owner}/{repo}/actions/runs")
    suspend fun getWorkflowRuns(
        @Header("Authorization") auth: String,
        @Path("owner") owner: String,
        @Path("repo") repo: String
    ): Response<GithubRunList>

    @GET("repos/{owner}/{repo}/actions/runs/{run_id}/logs")
    suspend fun getWorkflowRunLogs(
        @Header("Authorization") auth: String,
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Path("run_id") runId: Long
    ): Response<ResponseBody>

    @GET("repos/{owner}/{repo}/actions/runs/{run_id}/artifacts")
    suspend fun getWorkflowRunArtifacts(
        @Header("Authorization") auth: String,
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Path("run_id") runId: Long
    ): Response<GithubArtifactList>
    
    @GET
    suspend fun downloadArtifact(
        @Header("Authorization") auth: String,
        @Url url: String
    ): Response<ResponseBody>
}
