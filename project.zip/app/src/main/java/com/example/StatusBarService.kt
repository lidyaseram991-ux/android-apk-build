package com.example

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SignalCellular4Bar
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Bluetooth

class StatusBarService : AccessibilityService(), LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
    
    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    
    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()

    override val lifecycle: Lifecycle
        get() = lifecycleRegistry

    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateRegistryController.savedStateRegistry

    override val viewModelStore: ViewModelStore
        get() = store

    @SuppressLint("ClickableViewAccessibility")
    override fun onServiceConnected() {
        super.onServiceConnected()
        
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)

        createOverlayWindow()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
    }

    private fun createOverlayWindow() {
        if (!Settings.canDrawOverlays(this)) {
            return
        }

        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            getStatusBarHeight(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        layoutParams.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL

        overlayView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@StatusBarService)
            setViewTreeSavedStateRegistryOwner(this@StatusBarService)
            setViewTreeViewModelStoreOwner(this@StatusBarService)
            
            setContent {
                CustomStatusBar()
            }
        }
        
        // Pass touches through if not handled (swipe down)
        overlayView?.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                // If the user swipes down, we might want to perform the global action to show notifications
                // For simplicity, we just pass through touches or trigger action
                performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
                true
            } else {
                false
            }
        }

        windowManager.addView(overlayView, layoutParams)
    }

    private fun getStatusBarHeight(): Int {
        var result = 0
        val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
        if (resourceId > 0) {
            result = resources.getDimensionPixelSize(resourceId)
        }
        // Fallback for some devices
        if (result == 0) {
            result = (24 * resources.displayMetrics.density).toInt()
        }
        return result
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Not used for window drawing, but could be used to detect app changes
        // to change status bar color.
    }

    override fun onInterrupt() {
    }

    override fun onDestroy() {
        super.onDestroy()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        overlayView?.let {
            windowManager.removeView(it)
            overlayView = null
        }
    }
}

@Composable
fun CustomStatusBar() {
    val state by StatusBarSettings.settingsFlow.collectAsState()
    
    if (!state.isOverlayVisible) return
    
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight()
            .background(Color(state.backgroundColor).copy(alpha = state.backgroundAlpha))
            .padding(horizontal = 12.dp)
            .clearAndSetSemantics {},
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left Side: Charging Bolt, Battery, Network, Signal, and Extra Icons
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Real Notification Icons
                if (state.notificationBitmaps.isNotEmpty()) {
                    state.notificationBitmaps.forEach { bitmap ->
                        Image(
                            bitmap = bitmap.asImageBitmap(),
                            contentDescription = "Notification",
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                }

                if (!state.isBatteryOnRight) {
                    if (state.isAutoCharging) {
                        Icon(
                            imageVector = Icons.Filled.Bolt,
                            contentDescription = "Charging",
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    
                    CustomBatteryIcon(
                        percentage = state.batteryPercentage,
                        isInside = state.isPercentageInside,
                        style = state.batteryStyle
                    )
                    
                    Spacer(modifier = Modifier.width(6.dp))
                }
                
                Text(
                    text = state.networkType,
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.width(4.dp))
                
                // Signal bars
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(1.dp)) {
                    Box(modifier = Modifier.width(2.dp).height(4.dp).background(if (state.networkStrength >= 1) Color.White else Color.Gray))
                    Box(modifier = Modifier.width(2.dp).height(6.dp).background(if (state.networkStrength >= 2) Color.White else Color.Gray))
                    Box(modifier = Modifier.width(2.dp).height(8.dp).background(if (state.networkStrength >= 3) Color.White else Color.Gray))
                    Box(modifier = Modifier.width(2.dp).height(10.dp).background(if (state.networkStrength >= 4) Color.White else Color.Gray))
                }

                Spacer(modifier = Modifier.width(6.dp))
                
                if (state.showBluetooth) {
                    Icon(
                        imageVector = Icons.Filled.Bluetooth,
                        contentDescription = "Bluetooth",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                }
                
                if (state.showWifi) {
                    Icon(
                        imageVector = Icons.Filled.Wifi,
                        contentDescription = "WiFi",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                }
                
                if (state.showAlarm) {
                    Icon(
                        imageVector = Icons.Filled.Alarm,
                        contentDescription = "Alarm",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
            
            // Right Side: Time and other status
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.MoreHoriz,
                    contentDescription = "More",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                
                Icon(
                    imageVector = Icons.Filled.PlayArrow,
                    contentDescription = "Play",
                    tint = Color.White,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                
                Text(
                    text = "10:41",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
                
                if (state.isBatteryOnRight) {
                    Spacer(modifier = Modifier.width(6.dp))
                    
                    if (state.isAutoCharging) {
                        Icon(
                            imageVector = Icons.Filled.Bolt,
                            contentDescription = "Charging",
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    
                    CustomBatteryIcon(
                        percentage = state.batteryPercentage,
                        isInside = state.isPercentageInside,
                        style = state.batteryStyle
                    )
                }
            }
        }
    }
}

@Composable
fun CustomBatteryIcon(percentage: Int, isInside: Boolean, style: BatteryStyle) {
    val batteryColor = if (percentage > 20) Color(0xFF4CAF50) else Color(0xFFF44336)
    
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (!isInside && style != BatteryStyle.TEXT_ONLY) {
            Text(
                text = "$percentage%",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(end = 6.dp)
            )
        }
        
        when (style) {
            BatteryStyle.DEFAULT -> {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .width(28.dp)
                            .height(14.dp)
                            .border(1.dp, Color.White, RoundedCornerShape(2.dp))
                            .padding(1.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Start
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(percentage / 100f)
                                    .background(batteryColor, RoundedCornerShape(1.dp))
                            )
                        }
                        if (isInside) {
                            Text(
                                text = "$percentage",
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Box(modifier = Modifier.width(2.dp).height(6.dp).background(Color.White, RoundedCornerShape(topEnd = 1.dp, bottomEnd = 1.dp)))
                }
            }
            BatteryStyle.PORTRAIT -> {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(modifier = Modifier.height(2.dp).width(6.dp).background(Color.White, RoundedCornerShape(topStart = 1.dp, topEnd = 1.dp)))
                    Box(
                        modifier = Modifier
                            .width(14.dp)
                            .height(24.dp)
                            .border(1.dp, Color.White, RoundedCornerShape(2.dp))
                            .padding(1.dp),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        Column(
                            modifier = Modifier.fillMaxHeight(),
                            verticalArrangement = Arrangement.Bottom
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .fillMaxHeight(percentage / 100f)
                                    .background(batteryColor, RoundedCornerShape(1.dp))
                            )
                        }
                        if (isInside) {
                            Text(
                                text = "$percentage",
                                color = Color.White,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(bottom = 2.dp)
                            )
                        }
                    }
                }
            }
            BatteryStyle.CIRCLE -> {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(18.dp)) {
                    androidx.compose.material3.CircularProgressIndicator(
                        progress = percentage / 100f,
                        color = batteryColor,
                        strokeWidth = 2.dp,
                        modifier = Modifier.fillMaxSize()
                    )
                    if (isInside) {
                        Text(
                            text = "$percentage",
                            color = Color.White,
                            fontSize = 7.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            BatteryStyle.TEXT_ONLY -> {
                Text(
                    text = "$percentage%",
                    color = batteryColor,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
