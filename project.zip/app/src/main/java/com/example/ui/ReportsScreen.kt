package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.example.data.ExpenseEntity
import java.time.LocalDate
import java.time.DayOfWeek
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters
import kotlin.math.cos
import kotlin.math.sin

enum class ReportPeriod {
    TODAY, WEEK, MONTH, YEAR
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(navController: NavController, viewModel: BudgetViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var selectedPeriod by remember { mutableStateOf(ReportPeriod.WEEK) }

    val today = LocalDate.now()
    val filteredExpenses = uiState.expenses.filter { expense ->
        val date = expense.date
        when (selectedPeriod) {
            ReportPeriod.TODAY -> date == today
            ReportPeriod.WEEK -> {
                // Determine start of week (e.g. Saturday or Sunday depending on locale, let's just do past 7 days)
                val start = today.minusDays(6)
                !date.isBefore(start) && !date.isAfter(today)
            }
            ReportPeriod.MONTH -> date.year == today.year && date.month == today.month
            ReportPeriod.YEAR -> date.year == today.year
        }
    }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                title = { Text(string("reports_title")) }
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                PeriodSelector(selectedPeriod) { selectedPeriod = it }
            }

            item {
                LineChartCard(filteredExpenses, selectedPeriod)
            }

            item {
                SummaryCards(filteredExpenses, selectedPeriod)
            }

            item {
                DonutChartCard(filteredExpenses)
            }

            item {
                CategoryAnalysisList(filteredExpenses)
            }
            
            item { Spacer(modifier = Modifier.height(80.dp)) }
        }
    }
}

@Composable
fun PeriodSelector(selectedPeriod: ReportPeriod, onSelect: (ReportPeriod) -> Unit) {
    SingleChoiceSegmentedButtonRow(
        modifier = Modifier.fillMaxWidth()
    ) {
        val options = listOf(
            ReportPeriod.TODAY to string("period_today"),
            ReportPeriod.WEEK to string("period_week"),
            ReportPeriod.MONTH to string("period_month"),
            ReportPeriod.YEAR to string("period_year")
        )
        options.forEachIndexed { index, pair ->
            SegmentedButton(
                selected = selectedPeriod == pair.first,
                onClick = { onSelect(pair.first) },
                shape = SegmentedButtonDefaults.itemShape(index = index, count = options.size)
            ) {
                Text(pair.second)
            }
        }
    }
}

@Composable
fun LineChartCard(expenses: List<ExpenseEntity>, period: ReportPeriod) {
    val dailyTotals = expenses.groupBy { it.date }.mapValues { entry -> entry.value.sumOf { it.price } }
    
    // Sort dates
    var sortedDates = dailyTotals.keys.sorted()
    if (period == ReportPeriod.WEEK) {
        val today = LocalDate.now()
        val start = today.minusDays(6)
        sortedDates = (0..6).map { start.plusDays(it.toLong()) }
    } else if (sortedDates.isEmpty()) {
        sortedDates = listOf(LocalDate.now())
    }
    
    val chartData = sortedDates.map { it to (dailyTotals[it] ?: 0.0) }
    val maxVal = chartData.maxOfOrNull { it.second }?.takeIf { it > 0 } ?: 100.0

    var selectedPoint by remember { mutableStateOf<Pair<LocalDate, Double>?>(null) }
    
    val isEnglish = LocalAppLanguage.current
    val localeLocale = if (isEnglish) java.util.Locale.ENGLISH else java.util.Locale("ar")

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(string("total_expenses_chart"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))
            
            Box(modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
            ) {
                val lineColor = MaterialTheme.colorScheme.primary
                val pointColor = MaterialTheme.colorScheme.secondary
                val density = LocalDensity.current
                
                Canvas(modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(chartData) {
                        awaitPointerEventScope {
                            while (true) {
                                val event = awaitPointerEvent()
                                val position = event.changes.first().position
                                if (event.type == androidx.compose.ui.input.pointer.PointerEventType.Press || event.type == androidx.compose.ui.input.pointer.PointerEventType.Move) {
                                    if (chartData.size > 1) {
                                        val width = size.width.toFloat()
                                        val xStep = width / (chartData.size - 1)
                                        val index = (position.x / xStep).toInt().coerceIn(0, chartData.size - 1)
                                        // Just a simple heuristic for touch
                                        val xPos = index * xStep
                                        if (kotlin.math.abs(position.x - xPos) < xStep / 2) {
                                            selectedPoint = chartData[index]
                                        } else {
                                            selectedPoint = null
                                        }
                                    } else if (chartData.size == 1) {
                                        selectedPoint = chartData[0]
                                    }
                                }
                            }
                        }
                    }
                ) {
                    val width = size.width
                    val height = size.height
                    
                    if (chartData.size > 1) {
                        val path = Path()
                        val xStep = width / (chartData.size - 1)
                        
                        chartData.forEachIndexed { index, pair ->
                            val x = index * xStep
                            val y = height - ((pair.second / maxVal) * height).toFloat()
                            if (index == 0) {
                                path.moveTo(x, y)
                            } else {
                                path.lineTo(x, y)
                            }
                        }
                        
                        drawPath(
                            path = path,
                            color = lineColor,
                            style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                        )
                        
                        chartData.forEachIndexed { index, pair ->
                            val x = index * xStep
                            val y = height - ((pair.second / maxVal) * height).toFloat()
                            drawCircle(
                                color = if (selectedPoint == pair) pointColor else lineColor,
                                radius = if (selectedPoint == pair) 6.dp.toPx() else 4.dp.toPx(),
                                center = Offset(x, y)
                            )
                        }
                    } else if (chartData.isNotEmpty()) {
                        val x = width / 2
                        val y = height - ((chartData[0].second / maxVal) * height).toFloat()
                        drawCircle(
                            color = lineColor,
                            radius = 6.dp.toPx(),
                            center = Offset(x, y)
                        )
                    }
                }
                
                selectedPoint?.let { point ->
                    val dayStr = point.first.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, localeLocale)
                    val amountStr = numberFormat.format(point.second)
                    Card(
                        modifier = Modifier.align(Alignment.TopCenter),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.inverseSurface)
                    ) {
                        Text(
                            text = "$dayStr — $amountStr ${string("currency")}",
                            modifier = Modifier.padding(8.dp),
                            color = MaterialTheme.colorScheme.inverseOnSurface
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SummaryCards(expenses: List<ExpenseEntity>, period: ReportPeriod) {
    val total = expenses.sumOf { it.price }
    val count = expenses.size
    
    val days = expenses.map { it.date }.distinct().size
    val average = if (days > 0) total / days else 0.0
    
    val dailyTotals = expenses.groupBy { it.date }.mapValues { entry -> entry.value.sumOf { it.price } }
    val highestDay = dailyTotals.maxByOrNull { it.value }
    val isEnglish = LocalAppLanguage.current
    val localeLocale = if (isEnglish) java.util.Locale.ENGLISH else java.util.Locale("ar")

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            SummaryCard(
                title = string("total_expenses_chart"),
                value = "${numberFormat.format(total)} ${string("currency")}",
                modifier = Modifier.weight(1f)
            )
            SummaryCard(
                title = string("daily_average"),
                value = "${numberFormat.format(average)} ${string("currency")}",
                modifier = Modifier.weight(1f)
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            val highestText = if (highestDay != null) {
                val dayStr = highestDay.key.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, localeLocale)
                "$dayStr — ${numberFormat.format(highestDay.value)} ${string("currency")}"
            } else "-"
            
            SummaryCard(
                title = string("highest_spending_day"),
                value = highestText,
                modifier = Modifier.weight(1f)
            )
            SummaryCard(
                title = string("transactions_count"),
                value = count.toString(),
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun SummaryCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Composable
fun DonutChartCard(expenses: List<ExpenseEntity>) {
    val total = expenses.sumOf { it.price }
    if (total == 0.0) return

    val catTotals = expenses.groupBy { it.category }.mapValues { entry -> entry.value.sumOf { it.price } }
    val colors = listOf(
        Color(0xFF6200EA), Color(0xFF03DAC5), Color(0xFFFF0266),
        Color(0xFFFFD600), Color(0xFF00C853), Color(0xFFFF6D00)
    )

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(string("total_expenses_chart"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))
            
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(200.dp)) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    var startAngle = -90f
                    var i = 0
                    catTotals.forEach { (cat, amount) ->
                        val sweepAngle = ((amount / total) * 360).toFloat()
                        val strokeWidth = 32.dp.toPx()
                        val halfStroke = strokeWidth / 2
                        drawArc(
                            color = colors[i % colors.size],
                            startAngle = startAngle,
                            sweepAngle = sweepAngle,
                            useCenter = false,
                            topLeft = Offset(halfStroke, halfStroke),
                            size = Size(size.width - strokeWidth, size.height - strokeWidth),
                            style = Stroke(width = strokeWidth)
                        )
                        startAngle += sweepAngle
                        i++
                    }
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(string("total_expenses_chart"), style = MaterialTheme.typography.bodySmall)
                    Text("${numberFormat.format(total)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(string("currency"), style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun CategoryAnalysisList(expenses: List<ExpenseEntity>) {
    val total = expenses.sumOf { it.price }
    if (total == 0.0) return
    
    val catTotals = expenses.groupBy { it.category }.mapValues { entry -> entry.value.sumOf { it.price } }.entries.sortedByDescending { it.value }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(string("most_spent_categories"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))
            
            catTotals.forEach { (cat, amount) ->
                val percentage = (amount / total) * 100
                val catName = getCategoryName(cat)
                Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(catName, style = MaterialTheme.typography.bodyMedium)
                        Text("${numberFormat.format(amount)} ${string("currency")} (${"%.1f".format(percentage)}%)", style = MaterialTheme.typography.bodyMedium)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { (amount / total).toFloat() },
                        modifier = Modifier.fillMaxWidth().height(8.dp),
                        strokeCap = StrokeCap.Round
                    )
                }
            }
        }
    }
}

@Composable
fun getCategoryName(category: String): String {
    return when(category) {
        "food" -> "🍴 " + string("cat_food")
        "shopping" -> "🛍️ " + string("cat_shopping")
        "bills" -> "🧾 " + string("cat_bills")
        "tech" -> "💻 " + string("cat_tech")
        "other" -> "🏷️ " + string("cat_other")
        else -> category
    }
}
