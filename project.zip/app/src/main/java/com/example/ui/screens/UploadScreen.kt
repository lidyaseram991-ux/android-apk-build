package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Language
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R

@Composable
fun UploadScreen(
    viewModel: MainViewModel,
    onNavigateToRuns: () -> Unit,
    onToggleLanguage: () -> Unit
) {
    val uploadState by viewModel.uploadState.collectAsState()
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var uniqueId by remember { mutableStateOf("") }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        selectedUri = uri
    }

    Scaffold(
        topBar = {
            @OptIn(ExperimentalMaterial3Api::class)
            TopAppBar(
                title = { Text(stringResource(R.string.upload_project_title), fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                actions = {
                    IconButton(onClick = onToggleLanguage) {
                        Icon(Icons.Default.Language, contentDescription = "Change Language")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Icon(
                        Icons.Default.FolderZip,
                        contentDescription = "Zip",
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Button(onClick = { launcher.launch("application/zip") }) {
                        Text(stringResource(R.string.select_project_zip))
                    }

                    if (selectedUri != null) {
                        Text(
                            text = stringResource(R.string.selected_file, selectedUri?.lastPathSegment ?: ""),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Text(
                            text = stringResource(R.string.no_file_selected),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            OutlinedTextField(
                value = uniqueId,
                onValueChange = { uniqueId = it },
                label = { Text(stringResource(R.string.unique_package_id)) },
                supportingText = { Text(stringResource(R.string.unique_package_id_helper)) },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.weight(1f))

            when (uploadState) {
                is UploadState.Compressing, is UploadState.Uploading -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = if (uploadState is UploadState.Compressing) stringResource(R.string.preparing) else stringResource(R.string.uploading),
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
                is UploadState.Success -> {
                    Text(
                        stringResource(R.string.upload_successful),
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Button(
                        onClick = { onNavigateToRuns() },
                        modifier = Modifier.fillMaxWidth().height(56.dp)
                    ) {
                        Text(stringResource(R.string.view_builds))
                    }
                }
                is UploadState.Error -> {
                    Text(stringResource(R.string.error_msg, (uploadState as UploadState.Error).message), color = MaterialTheme.colorScheme.error)
                }
                else -> {}
            }

            if (uploadState !is UploadState.Success) {
                Button(
                    onClick = { 
                        selectedUri?.let { uri ->
                            if (uniqueId.isNotBlank()) {
                                viewModel.uploadZipFile(uri, uniqueId)
                            } else {
                                viewModel.uploadZipFile(uri)
                            }
                        }
                    },
                    enabled = selectedUri != null && uploadState !is UploadState.Compressing && uploadState !is UploadState.Uploading,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                ) {
                    Icon(Icons.Default.CloudUpload, contentDescription = stringResource(R.string.upload_and_build))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(stringResource(R.string.upload_and_build))
                }
            }
        }
    }
}
