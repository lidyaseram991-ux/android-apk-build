package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Language
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import kotlinx.coroutines.launch

@Composable
fun RunsScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onToggleLanguage: () -> Unit
) {
    val runs by viewModel.runs.collectAsState()
    val pollingError by viewModel.pollingError.collectAsState()
    val logs by viewModel.logs.collectAsState()
    
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    
    var selectedRunId by remember { mutableStateOf<Long?>(null) }
    
    DisposableEffect(Unit) {
        viewModel.startPolling()
        onDispose { viewModel.stopPolling() }
    }

    Scaffold(
        topBar = {
            @OptIn(ExperimentalMaterial3Api::class)
            TopAppBar(
                title = { Text(stringResource(R.string.build_runs_title)) },
                actions = {
                    IconButton(onClick = onToggleLanguage) {
                        Icon(Icons.Default.Language, contentDescription = "Change Language")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            if (pollingError != null) {
                Text(text = stringResource(R.string.error_msg, pollingError ?: ""), color = MaterialTheme.colorScheme.error)
            }
            
            LazyColumn(
                modifier = Modifier.weight(1f)
            ) {
                items(runs) { run ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { 
                                selectedRunId = run.id
                                viewModel.fetchLogs(run.id)
                            },
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(stringResource(R.string.run_id_format, run.id), style = MaterialTheme.typography.titleMedium)
                            Text(stringResource(R.string.message_format, run.head_commit?.message ?: stringResource(R.string.no_message)))
                            Text(stringResource(R.string.status_format, run.status ?: stringResource(R.string.queued)))
                            Text(stringResource(R.string.conclusion_format, run.conclusion ?: stringResource(R.string.not_available)))
                            
                            if (run.conclusion == "success") {
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = {
                                        scope.launch {
                                            try {
                                                val path = viewModel.downloadArtifact(run.id)
                                                Toast.makeText(context, context.getString(R.string.downloaded_to, path), Toast.LENGTH_LONG).show()
                                            } catch (e: Exception) {
                                                Toast.makeText(context, context.getString(R.string.download_failed, e.message), Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.Download, contentDescription = stringResource(R.string.download_apk))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(stringResource(R.string.download_apk))
                                }
                            }
                        }
                    }
                }
            }
            
            if (selectedRunId != null) {
                Spacer(modifier = Modifier.height(16.dp))
                Text(stringResource(R.string.logs_for_run, selectedRunId!!), style = MaterialTheme.typography.titleMedium)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    val scrollState = rememberScrollState()
                    Text(
                        text = logs,
                        modifier = Modifier
                            .padding(8.dp)
                            .verticalScroll(scrollState),
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                    )
                }
            }
        }
    }
}
