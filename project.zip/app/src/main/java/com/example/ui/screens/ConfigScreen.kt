package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R

@Composable
fun ConfigScreen(
    viewModel: MainViewModel,
    onNavigateToUpload: () -> Unit,
    onToggleLanguage: () -> Unit
) {
    val pat by viewModel.patFlow.collectAsState(initial = "")
    val owner by viewModel.ownerFlow.collectAsState(initial = "")
    val repo by viewModel.repoFlow.collectAsState(initial = "")

    var patInput by remember { mutableStateOf("") }
    var ownerInput by remember { mutableStateOf("") }
    var repoInput by remember { mutableStateOf("") }

    LaunchedEffect(pat, owner, repo) {
        if (patInput.isEmpty() && !pat.isNullOrEmpty()) patInput = pat ?: ""
        if (ownerInput.isEmpty() && !owner.isNullOrEmpty()) ownerInput = owner ?: ""
        if (repoInput.isEmpty() && !repo.isNullOrEmpty()) repoInput = repo ?: ""
    }

    Scaffold(
        topBar = {
            @OptIn(ExperimentalMaterial3Api::class)
            TopAppBar(
                title = { Text(stringResource(R.string.config_title), fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                actions = {
                    IconButton(onClick = onToggleLanguage) {
                        Icon(Icons.Default.Language, contentDescription = "Change Language")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            Text(
                text = stringResource(R.string.github_credentials),
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.primary
            )
            
            OutlinedTextField(
                value = patInput,
                onValueChange = { patInput = it },
                label = { Text(stringResource(R.string.github_pat)) },
                supportingText = { Text(stringResource(R.string.pat_helper_text)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            OutlinedTextField(
                value = ownerInput,
                onValueChange = { ownerInput = it },
                label = { Text(stringResource(R.string.repo_owner)) },
                supportingText = { Text(stringResource(R.string.repo_owner_helper)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            OutlinedTextField(
                value = repoInput,
                onValueChange = { repoInput = it },
                label = { Text(stringResource(R.string.repo_name)) },
                supportingText = { Text(stringResource(R.string.repo_name_helper)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = {
                    viewModel.saveConfig(patInput, ownerInput, repoInput)
                    onNavigateToUpload()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) {
                Icon(Icons.Default.Save, contentDescription = stringResource(R.string.save_and_continue))
                Spacer(modifier = Modifier.width(8.dp))
                Text(stringResource(R.string.save_and_continue))
            }
        }
    }
}
