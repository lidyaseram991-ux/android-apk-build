package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConfigScreen(
    viewModel: MainViewModel,
    onNavigateToUpload: () -> Unit,
    onToggleLanguage: () -> Unit
) {
    val pat by viewModel.patFlow.collectAsState(initial = "")
    var patInput by remember { mutableStateOf("") }
    
    val reposList by viewModel.reposList.collectAsState()
    val reposLoading by viewModel.reposLoading.collectAsState()
    
    var showCreateDialog by remember { mutableStateOf(false) }

    LaunchedEffect(pat) {
        if (patInput.isEmpty() && !pat.isNullOrEmpty()) {
            patInput = pat ?: ""
            viewModel.fetchRepos()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.config_title), fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                actions = {
                    IconButton(onClick = onToggleLanguage) {
                        Icon(Icons.Default.Language, contentDescription = "Change Language")
                    }
                }
            )
        },
        floatingActionButton = {
            if (patInput.isNotBlank()) {
                FloatingActionButton(onClick = { showCreateDialog = true }) {
                    Icon(Icons.Default.Add, contentDescription = stringResource(R.string.create_new_repo))
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = stringResource(R.string.github_credentials),
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.primary
            )
            
            OutlinedTextField(
                value = patInput,
                onValueChange = { patInput = it },
                label = { Text(stringResource(R.string.github_pat)) },
                supportingText = { Text(stringResource(R.string.pat_helper_text)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Button(
                onClick = { 
                    viewModel.saveConfig(patInput, "", "")
                    viewModel.fetchRepos()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(stringResource(R.string.load_repositories))
            }
            
            if (reposLoading) {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.CenterHorizontally))
            } else if (reposList.isNotEmpty()) {
                Text(
                    text = stringResource(R.string.repositories),
                    style = MaterialTheme.typography.titleMedium
                )
                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(reposList) { repo ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable {
                                    viewModel.saveConfig(patInput, repo.owner.login, repo.name)
                                    onNavigateToUpload()
                                },
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (repo.private) Icons.Default.Lock else Icons.Default.Public,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.width(16.dp))
                                Column {
                                    Text(text = repo.full_name, style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        text = if (repo.private) stringResource(R.string.private_badge) else stringResource(R.string.public_repo),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        var repoName by remember { mutableStateOf("") }
        var repoDesc by remember { mutableStateOf("") }
        var isPrivate by remember { mutableStateOf(true) }
        
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text(stringResource(R.string.create_new_repo)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = repoName,
                        onValueChange = { repoName = it },
                        label = { Text(stringResource(R.string.repo_name)) },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = repoDesc,
                        onValueChange = { repoDesc = it },
                        label = { Text(stringResource(R.string.repo_description)) },
                        maxLines = 3
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isPrivate, onCheckedChange = { isPrivate = it })
                        Text(stringResource(R.string.private_repo))
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.createRepo(repoName, repoDesc, isPrivate) { owner, name ->
                            viewModel.saveConfig(patInput, owner, name)
                            showCreateDialog = false
                            onNavigateToUpload()
                        }
                    },
                    enabled = repoName.isNotBlank()
                ) {
                    Text(stringResource(R.string.create))
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }
}
