package com.example.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.example.data.ExpenseEntity
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(navController: NavController, viewModel: BudgetViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text("لوحة التحكم") },
                actions = {
                    IconButton(onClick = { navController.navigate(Routes.HISTORY) }) {
                        Icon(Icons.Default.List, contentDescription = "السجل")
                    }
                    IconButton(onClick = { navController.navigate(Routes.BUDGET_CONFIG) }) {
                        Icon(Icons.Default.Settings, contentDescription = "الإعدادات")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { navController.navigate(Routes.ADD_EXPENSE) },
                modifier = Modifier.testTag("add_expense_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة مصروف")
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                if (uiState.initialBudget == 0.0) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.9f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("أهلاً بك!", style = MaterialTheme.typography.titleLarge)
                            Text("يرجى ضبط الميزانية الأصلية للبدء.")
                            Button(
                                onClick = { navController.navigate(Routes.BUDGET_CONFIG) },
                                modifier = Modifier.padding(top = 8.dp)
                            ) {
                                Text("ضبط الميزانية")
                            }
                        }
                    }
                }
            }

            if (uiState.isWarning || uiState.isCritical) {
                item {
                    AlertBanner(isCritical = uiState.isCritical)
                }
            }

            item {
                BudgetOverviewCard(uiState = uiState)
            }

            item {
                RunwayCard(uiState = uiState)
            }

            item {
                Text(
                    text = "أحدث المصاريف",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            items(uiState.expenses.take(5)) { expense ->
                ExpenseItemRow(expense = expense, onDelete = { viewModel.deleteExpense(it) })
            }
        }
    }
}

@Composable
fun AlertBanner(isCritical: Boolean) {
    val containerColor = if (isCritical) MaterialTheme.colorScheme.errorContainer else Color(0xFFFFE082) // Amber
    val contentColor = if (isCritical) MaterialTheme.colorScheme.onErrorContainer else Color(0xFF5D4037)

    Card(
        colors = CardDefaults.cardColors(containerColor = containerColor.copy(alpha = 0.9f), contentColor = contentColor),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Warning, contentDescription = "تحذير", modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(
                    text = if (isCritical) "حالة حرجة!" else "تحذير!",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isCritical) "رصيدك أقل من 20% أو يكفيك لأقل من 5 أيام." else "رصيدك أقل من 50% من الميزانية.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

@Composable
fun BudgetOverviewCard(uiState: BudgetUiState) {
    val progressRatio = if (uiState.initialBudget > 0) {
        (uiState.remainingBalance / uiState.initialBudget).toFloat().coerceIn(0f, 1f)
    } else {
        0f
    }
    
    val animatedProgress by animateFloatAsState(
        targetValue = progressRatio,
        animationSpec = tween(durationMillis = 1000),
        label = "progressAnimation"
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(160.dp)) {
                CircularProgressIndicator(
                    progress = { 1f },
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    strokeWidth = 12.dp
                )
                CircularProgressIndicator(
                    progress = { animatedProgress },
                    modifier = Modifier.fillMaxSize(),
                    color = if (uiState.isCritical) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                    strokeWidth = 12.dp,
                    strokeCap = StrokeCap.Round
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("المبلغ المتبقي", style = MaterialTheme.typography.labelMedium)
                    Text(
                        String.format("%.2f", uiState.remainingBalance),
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("الميزانية الأصلية", style = MaterialTheme.typography.labelSmall)
                    Text(String.format("%.2f", uiState.initialBudget), style = MaterialTheme.typography.bodyLarge)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("إجمالي المصاريف", style = MaterialTheme.typography.labelSmall)
                    Text(String.format("%.2f", uiState.totalSpent), style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

@Composable
fun RunwayCard(uiState: BudgetUiState) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.9f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("تحليل معدل الاستهلاك", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            
            Text("معدل الحرق اليومي: ${String.format("%.2f", uiState.dailyBurnRate)}")
            Text("معدل الحرق الأسبوعي: ${String.format("%.2f", uiState.weeklyBurnRate)}")
            Spacer(modifier = Modifier.height(8.dp))
            
            if (uiState.runwayDays != null) {
                Text("المبلغ المتبقي يكفيك لمدة:", fontWeight = FontWeight.SemiBold)
                Text("${uiState.runwayDays} يوم / ${uiState.runwayWeeks} أسبوع / ${uiState.runwayMonths} شهر")
                
                Spacer(modifier = Modifier.height(8.dp))
                if (uiState.runwayDays >= uiState.daysLeftInMonth) {
                    Text("✅ ممتاز! معدل إنفاقك الحالي يضمن بقاء الميزانية حتى نهاية الشهر.", color = Color(0xFF388E3C), style = MaterialTheme.typography.bodyMedium)
                } else {
                    Text("⚠️ تنبيه: معدل إنفاقك مرتفع، الميزانية ستنفد قبل نهاية الشهر (${uiState.daysLeftInMonth} أيام متبقية).", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                }
            } else {
                Text("بيانات الاستهلاك غير كافية لحساب المدى.", color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.7f))
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            Divider(color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.2f))
            Spacer(modifier = Modifier.height(8.dp))
            Text("الحد اليومي المقترح للإنفاق (لنهاية الشهر):", fontWeight = FontWeight.SemiBold)
            Text(
                String.format("%.2f", uiState.recommendedDailyLimit),
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
fun ExpenseItemRow(expense: ExpenseEntity, onDelete: (ExpenseEntity) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f))
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(expense.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                val formattedTime = expense.time.format(DateTimeFormatter.ofPattern("hh:mm a"))
                Text("${expense.category} - ${expense.date}  $formattedTime", style = MaterialTheme.typography.bodySmall)
            }
            Text(
                String.format("%.2f", expense.price),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(horizontal = 8.dp)
            )
            IconButton(onClick = { onDelete(expense) }) {
                Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}
