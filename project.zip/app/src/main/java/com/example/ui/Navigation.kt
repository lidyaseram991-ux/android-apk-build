package com.example.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import coil.compose.AsyncImage
import com.example.R
import java.io.File

object Routes {
    const val DASHBOARD = "dashboard"
    const val ADD_EXPENSE = "add_expense"
    const val HISTORY = "history"
    const val BUDGET_CONFIG = "budget_config"
}

@Composable
fun MainNavigation() {
    val navController = rememberNavController()
    val budgetViewModel: BudgetViewModel = viewModel()
    val uiState by budgetViewModel.uiState.collectAsStateWithLifecycle()

    Box(modifier = Modifier.fillMaxSize()) {
        // Draw background based on theme
        when (uiState.appTheme) {
            "calm" -> {
                Image(
                    painter = painterResource(id = R.drawable.bg_calm_1788350001573),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            "nature" -> {
                Image(
                    painter = painterResource(id = R.drawable.bg_nature_1788350022571),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            "night" -> {
                Image(
                    painter = painterResource(id = R.drawable.bg_night_1788350844956),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            "ocean" -> {
                Image(
                    painter = painterResource(id = R.drawable.bg_ocean_1788350857283),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            "sunset" -> {
                Image(
                    painter = painterResource(id = R.drawable.bg_sunset_1788350871753),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            "geometric" -> {
                Image(
                    painter = painterResource(id = R.drawable.bg_geometric_1788350884857),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            "mint" -> {
                Image(
                    painter = painterResource(id = R.drawable.bg_mint_1788350897526),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            "default" -> {
                // Empty, uses default Surface color
            }
            else -> {
                // Try to load custom background
                if (uiState.appTheme.startsWith("/")) {
                    AsyncImage(
                        model = File(uiState.appTheme),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
            }
        }

        NavHost(navController = navController, startDestination = Routes.DASHBOARD) {
            composable(Routes.DASHBOARD) {
                DashboardScreen(navController = navController, viewModel = budgetViewModel)
            }
            composable(Routes.ADD_EXPENSE) {
                AddExpenseScreen(navController = navController, viewModel = budgetViewModel)
            }
            composable(Routes.HISTORY) {
                HistoryScreen(navController = navController, viewModel = budgetViewModel)
            }
            composable(Routes.BUDGET_CONFIG) {
                BudgetConfigScreen(navController = navController, viewModel = budgetViewModel)
            }
        }
    }
}
