package com.example.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import coil.compose.AsyncImage
import com.example.R
import java.io.File
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.unit.dp


object Routes {
    const val DASHBOARD = "dashboard"
    const val ADD_EXPENSE = "add_expense"
    const val HISTORY = "history"
    const val BUDGET_CONFIG = "budget_config"
    const val REPORTS = "reports"
}

@Composable
fun MainNavigation() {
    val navController = rememberNavController()
    val budgetViewModel: BudgetViewModel = viewModel()
    val uiState by budgetViewModel.uiState.collectAsStateWithLifecycle()
    val layoutDirection = if (uiState.isEnglish) androidx.compose.ui.unit.LayoutDirection.Ltr else androidx.compose.ui.unit.LayoutDirection.Rtl

    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.ui.platform.LocalLayoutDirection provides layoutDirection,
        LocalAppLanguage provides uiState.isEnglish
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Draw background based on theme
        when (uiState.appTheme) {
            "calm" -> {
                Image(
                    painter = painterResource(id = R.drawable.bg_calm_1788350001573),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            "nature" -> {
                Image(
                    painter = painterResource(id = R.drawable.bg_nature_1788350022571),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            "night" -> {
                Image(
                    painter = painterResource(id = R.drawable.bg_night_1788350844956),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            "ocean" -> {
                Image(
                    painter = painterResource(id = R.drawable.bg_ocean_1788350857283),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            "sunset" -> {
                Image(
                    painter = painterResource(id = R.drawable.bg_sunset_1788350871753),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            "geometric" -> {
                Image(
                    painter = painterResource(id = R.drawable.bg_geometric_1788350884857),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            "mint" -> {
                Image(
                    painter = painterResource(id = R.drawable.bg_mint_1788350897526),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            "default" -> {
                // Empty, uses default Surface color
            }
            else -> {
                // Try to load custom background
                if (uiState.appTheme.startsWith("/")) {
                    AsyncImage(
                        model = File(uiState.appTheme),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
            }
        }

        val navBackStackEntry by navController.currentBackStackEntryAsState()
        val currentRoute = navBackStackEntry?.destination?.route
        val mainRoutes = listOf(Routes.DASHBOARD, Routes.REPORTS, Routes.HISTORY, Routes.BUDGET_CONFIG)
        val showBottomBar = currentRoute in mainRoutes

        Scaffold(
            containerColor = androidx.compose.ui.graphics.Color.Transparent,
            bottomBar = {
                if (showBottomBar) {
                    NavigationBar(
                        containerColor = androidx.compose.ui.graphics.Color.Transparent
                    ) {
                        NavigationBarItem(
                            icon = { Icon(Icons.Default.Home, contentDescription = string("home")) },
                            label = { Text(string("home")) },
                            selected = currentRoute == Routes.DASHBOARD,
                            onClick = {
                                if (currentRoute != Routes.DASHBOARD) {
                                    navController.navigate(Routes.DASHBOARD) {
                                        popUpTo(Routes.DASHBOARD) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            }
                        )
                        NavigationBarItem(
                            icon = { Icon(Icons.Default.BarChart, contentDescription = string("reports_title")) },
                            label = { Text(string("reports_title")) },
                            selected = currentRoute == Routes.REPORTS,
                            onClick = {
                                if (currentRoute != Routes.REPORTS) {
                                    navController.navigate(Routes.REPORTS) {
                                        popUpTo(Routes.DASHBOARD) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            }
                        )
                        Box(modifier = Modifier.weight(1f), contentAlignment = androidx.compose.ui.Alignment.Center) {
                            FloatingActionButton(
                                onClick = { navController.navigate(Routes.ADD_EXPENSE) },
                                shape = CircleShape,
                                containerColor = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.offset(y = (-16).dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = string("add_expense_title"), tint = MaterialTheme.colorScheme.onPrimary)
                            }
                        }
                        NavigationBarItem(
                            icon = { Icon(Icons.Default.List, contentDescription = string("history_title")) },
                            label = { Text(string("history_title")) },
                            selected = currentRoute == Routes.HISTORY,
                            onClick = {
                                if (currentRoute != Routes.HISTORY) {
                                    navController.navigate(Routes.HISTORY) {
                                        popUpTo(Routes.DASHBOARD) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            }
                        )
                        NavigationBarItem(
                            icon = { Icon(Icons.Default.Settings, contentDescription = string("settings_title")) },
                            label = { Text(string("settings_title")) },
                            selected = currentRoute == Routes.BUDGET_CONFIG,
                            onClick = {
                                if (currentRoute != Routes.BUDGET_CONFIG) {
                                    navController.navigate(Routes.BUDGET_CONFIG) {
                                        popUpTo(Routes.DASHBOARD) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            }
                        )
                    }
                }
            }
        ) { paddingValues ->
            NavHost(
                navController = navController, 
                startDestination = Routes.DASHBOARD,
                modifier = Modifier.padding(bottom = paddingValues.calculateBottomPadding())
            ) {
                composable(Routes.DASHBOARD) {
                    DashboardScreen(navController = navController, viewModel = budgetViewModel)
                }
                composable(Routes.ADD_EXPENSE) {
                    AddExpenseScreen(navController = navController, viewModel = budgetViewModel)
                }
                composable(Routes.HISTORY) {
                    HistoryScreen(navController = navController, viewModel = budgetViewModel)
                }
                composable(Routes.BUDGET_CONFIG) {
                    BudgetConfigScreen(navController = navController, viewModel = budgetViewModel)
                }
                composable(Routes.REPORTS) {
                    ReportsScreen(navController = navController, viewModel = budgetViewModel)
                }
            }
        }
        }
    }
}
