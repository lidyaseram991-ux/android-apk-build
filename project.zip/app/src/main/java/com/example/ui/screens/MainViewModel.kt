package com.example.ui.screens

import android.app.Application
import android.net.Uri
import android.util.Base64
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.DataStoreManager
import com.example.data.GithubContentRequest
import com.example.data.GithubRun
import com.example.data.RetrofitClient
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import okhttp3.ResponseBody
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.UUID

sealed class UploadState {
    object Idle : UploadState()
    object Compressing : UploadState()
    object Uploading : UploadState()
    data class Success(val commitSha: String) : UploadState()
    data class Error(val message: String) : UploadState()
}

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val dataStore = DataStoreManager(application)
    
    val patFlow = dataStore.patFlow
    val ownerFlow = dataStore.ownerFlow
    val repoFlow = dataStore.repoFlow

    private val _uploadState = MutableStateFlow<UploadState>(UploadState.Idle)
    val uploadState: StateFlow<UploadState> = _uploadState.asStateFlow()
    
    private val _runs = MutableStateFlow<List<GithubRun>>(emptyList())
    val runs: StateFlow<List<GithubRun>> = _runs.asStateFlow()
    
    private val _pollingError = MutableStateFlow<String?>(null)
    val pollingError: StateFlow<String?> = _pollingError.asStateFlow()

    private val _logs = MutableStateFlow<String>("")
    val logs: StateFlow<String> = _logs.asStateFlow()

    fun saveConfig(pat: String, owner: String, repo: String) {
        viewModelScope.launch {
            dataStore.saveConfig(pat, owner, repo)
        }
    }

    fun uploadZipFile(uri: Uri, uniqueId: String = UUID.randomUUID().toString().take(8)) {
        viewModelScope.launch {
            _uploadState.value = UploadState.Compressing
            
            val pat = patFlow.first() ?: return@launch
            val owner = ownerFlow.first() ?: return@launch
            val repo = repoFlow.first() ?: return@launch
            val auth = "Bearer $pat"
            
            try {
                val context = getApplication<Application>().applicationContext
                val inputStream = context.contentResolver.openInputStream(uri)
                if (inputStream == null) {
                    _uploadState.value = UploadState.Error("Failed to open file")
                    return@launch
                }
                
                // Add unique ID file to the zip
                val modifiedBytes = appendUniqueIdToZip(inputStream, uniqueId)
                
                // Read and base64 encode
                val base64Content = Base64.encodeToString(modifiedBytes, Base64.NO_WRAP)
                
                _uploadState.value = UploadState.Uploading
                
                val path = "project.zip"
                
                // Get current SHA if exists
                var sha: String? = null
                try {
                    val getResponse = RetrofitClient.api.getFileContent(auth, owner, repo, path)
                    if (getResponse.isSuccessful) {
                        sha = getResponse.body()?.content?.sha
                    }
                } catch (e: Exception) {
                    // Ignore, file might not exist
                }
                
                val message = "Upload project.zip [ID: $uniqueId]"
                
                val request = GithubContentRequest(message, base64Content, sha)
                val putResponse = RetrofitClient.api.updateFileContent(auth, owner, repo, path, request)
                
                if (putResponse.isSuccessful) {
                    _uploadState.value = UploadState.Success(putResponse.body()?.content?.sha ?: "")
                    startPolling()
                } else {
                    _uploadState.value = UploadState.Error("Upload failed: ${putResponse.errorBody()?.string()}")
                }
            } catch (e: Exception) {
                _uploadState.value = UploadState.Error("Exception: ${e.message}")
            }
        }
    }
    
    private var isPolling = false
    
    fun startPolling() {
        if (isPolling) return
        isPolling = true
        viewModelScope.launch {
            while (isPolling) {
                pollRuns()
                delay(3000)
            }
        }
    }
    
    fun stopPolling() {
        isPolling = false
    }
    
    private suspend fun pollRuns() {
        val pat = patFlow.first() ?: return
        val owner = ownerFlow.first() ?: return
        val repo = repoFlow.first() ?: return
        val auth = "Bearer $pat"
        
        try {
            val response = RetrofitClient.api.getWorkflowRuns(auth, owner, repo)
            if (response.isSuccessful) {
                _runs.value = response.body()?.workflowRuns ?: emptyList()
                _pollingError.value = null
            } else {
                _pollingError.value = "Failed to fetch runs: ${response.code()}"
            }
        } catch (e: Exception) {
            _pollingError.value = "Error fetching runs: ${e.message}"
        }
    }
    
    fun fetchLogs(runId: Long) {
        viewModelScope.launch {
            val pat = patFlow.first() ?: return@launch
            val owner = ownerFlow.first() ?: return@launch
            val repo = repoFlow.first() ?: return@launch
            val auth = "Bearer $pat"
            
            try {
                // The logs endpoint usually returns a redirect (302) to a zip file.
                // Retrofit/OkHttp handles the redirect automatically, so we get the zip as ResponseBody.
                val response = RetrofitClient.api.getWorkflowRunLogs(auth, owner, repo, runId)
                if (response.isSuccessful) {
                    val body = response.body()
                    if (body != null) {
                        _logs.value = "Downloaded logs archive (${body.contentLength()} bytes)."
                        // Note: Unzipping logs here is complex as it contains multiple files per job.
                        // We will just indicate that it was downloaded. 
                    } else {
                        _logs.value = "Empty logs response."
                    }
                } else {
                    _logs.value = "Logs not available yet or error: ${response.code()}"
                }
            } catch (e: Exception) {
                _logs.value = "Error fetching logs: ${e.message}"
            }
        }
    }

    suspend fun downloadArtifact(runId: Long): String {
        val pat = patFlow.first() ?: throw Exception("No PAT")
        val owner = ownerFlow.first() ?: throw Exception("No owner")
        val repo = repoFlow.first() ?: throw Exception("No repo")
        val auth = "Bearer $pat"
        
        val artifactsResponse = RetrofitClient.api.getWorkflowRunArtifacts(auth, owner, repo, runId)
        if (!artifactsResponse.isSuccessful) throw Exception("Failed to list artifacts")
        
        val artifacts = artifactsResponse.body()?.artifacts ?: emptyList()
        val apkArtifact = artifacts.firstOrNull { it.name.contains("apk", ignoreCase = true) } 
                          ?: artifacts.firstOrNull() 
                          ?: throw Exception("No artifacts found")
                          
        val downloadResponse = RetrofitClient.api.downloadArtifact(auth, apkArtifact.archive_download_url)
        if (!downloadResponse.isSuccessful) throw Exception("Failed to download artifact")
        
        val context = getApplication<Application>().applicationContext
        val file = File(context.getExternalFilesDir(null), "${apkArtifact.name}.zip")
        
        downloadResponse.body()?.byteStream()?.use { inputStream ->
            FileOutputStream(file).use { outputStream ->
                inputStream.copyTo(outputStream)
            }
        }
        
        return file.absolutePath
    }

    private fun appendUniqueIdToZip(inputStream: InputStream, uniqueId: String): ByteArray {
        val baos = ByteArrayOutputStream()
        val zos = java.util.zip.ZipOutputStream(baos)
        val zis = java.util.zip.ZipInputStream(inputStream)
        try {
            var entry = zis.nextEntry
            while (entry != null) {
                val newEntry = java.util.zip.ZipEntry(entry.name)
                zos.putNextEntry(newEntry)
                zis.copyTo(zos)
                zos.closeEntry()
                entry = zis.nextEntry
            }
            // Add unique file
            val uniqueEntry = java.util.zip.ZipEntry("build_id.txt")
            zos.putNextEntry(uniqueEntry)
            zos.write(uniqueId.toByteArray())
            zos.closeEntry()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            zis.close()
            zos.close()
        }
        return baos.toByteArray()
    }
}
