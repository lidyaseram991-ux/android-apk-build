package com.example.ui.screens

import android.app.Application
import android.net.Uri
import android.util.Base64
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.DataStoreManager
import com.example.data.GithubContentRequest
import com.example.data.GithubRun
import com.example.data.RetrofitClient
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import okhttp3.ResponseBody
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.UUID

sealed class UploadState {
    object Idle : UploadState()
    object Compressing : UploadState()
    object Uploading : UploadState()
    data class Success(val commitSha: String) : UploadState()
    data class Error(val message: String) : UploadState()
}

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val dataStore = DataStoreManager(application)
    
    val patFlow = dataStore.patFlow
    val ownerFlow = dataStore.ownerFlow
    val repoFlow = dataStore.repoFlow

    private val _uploadState = MutableStateFlow<UploadState>(UploadState.Idle)
    val uploadState: StateFlow<UploadState> = _uploadState.asStateFlow()
    
    private val _runs = MutableStateFlow<List<GithubRun>>(emptyList())
    val runs: StateFlow<List<GithubRun>> = _runs.asStateFlow()
    
    private val _pollingError = MutableStateFlow<String?>(null)
    val pollingError: StateFlow<String?> = _pollingError.asStateFlow()

    private val _logs = MutableStateFlow<String>("")
    val logs: StateFlow<String> = _logs.asStateFlow()

    private val _reposList = MutableStateFlow<List<com.example.data.GithubRepo>>(emptyList())
    val reposList: StateFlow<List<com.example.data.GithubRepo>> = _reposList.asStateFlow()

    private val _reposLoading = MutableStateFlow(false)
    val reposLoading: StateFlow<Boolean> = _reposLoading.asStateFlow()

    private val _workflowSetupState = MutableStateFlow<String?>(null)
    val workflowSetupState: StateFlow<String?> = _workflowSetupState.asStateFlow()

    fun clearWorkflowState() {
        _workflowSetupState.value = null
    }

    fun fetchRepos() {
        viewModelScope.launch {
            val pat = patFlow.first()
            if (pat.isNullOrEmpty()) return@launch
            
            _reposLoading.value = true
            try {
                val auth = "Bearer $pat"
                val response = RetrofitClient.api.getUserRepos(auth)
                if (response.isSuccessful) {
                    _reposList.value = response.body() ?: emptyList()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _reposLoading.value = false
            }
        }
    }

    fun createRepo(name: String, description: String, isPrivate: Boolean, onCreated: (String, String) -> Unit) {
        viewModelScope.launch {
            val pat = patFlow.first() ?: return@launch
            val auth = "Bearer $pat"
            try {
                val response = RetrofitClient.api.createRepo(auth, com.example.data.CreateRepoRequest(name, description, isPrivate))
                if (response.isSuccessful) {
                    val repo = response.body()
                    if (repo != null) {
                        val owner = repo.owner.login
                        val repoName = repo.name
                        setupWorkflow(pat, owner, repoName, autoTrigger = true)
                        onCreated(owner, repoName)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun manualSetupWorkflow() {
        viewModelScope.launch {
            val pat = patFlow.first() ?: return@launch
            val owner = ownerFlow.first() ?: return@launch
            val repo = repoFlow.first() ?: return@launch
            setupWorkflow(pat, owner, repo, autoTrigger = false)
        }
    }

    fun uploadCustomWorkflow(uri: Uri) {
        viewModelScope.launch {
            _workflowSetupState.value = "setup_started"
            val pat = patFlow.first() ?: return@launch
            val owner = ownerFlow.first() ?: return@launch
            val repo = repoFlow.first() ?: return@launch
            
            try {
                val context = getApplication<Application>().applicationContext
                val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                if (bytes == null) {
                    _workflowSetupState.value = "setup_failed:Failed to read file"
                    return@launch
                }
                val base64Content = Base64.encodeToString(bytes, Base64.NO_WRAP)
                executeWorkflowUpload(pat, owner, repo, base64Content, autoTrigger = false)
            } catch(e: Exception) {
                _workflowSetupState.value = "setup_failed:${e.message}"
            }
        }
    }

    private suspend fun setupWorkflow(pat: String, owner: String, repo: String, autoTrigger: Boolean) {
        val yamlContent = """
name: Android CI

on:
  push:
    branches: [ "main", "master" ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
    - name: Checkout
      uses: actions/checkout@v4
    
    - name: Unzip project
      run: unzip project.zip -d app_project || echo "No project.zip found"
      
    - name: set up JDK 17
      uses: actions/setup-java@v3
      with:
        java-version: '17'
        distribution: 'temurin'
        
    - name: Grant execute permission for gradlew
      run: cd app_project && chmod +x gradlew || true
      
    - name: Build with Gradle
      run: cd app_project && ./gradlew assembleDebug || true
      
    - name: Upload APK
      uses: actions/upload-artifact@v4
      with:
        name: app-debug-apk
        path: app_project/app/build/outputs/apk/debug/*.apk
        """.trimIndent()
        
        val base64Content = Base64.encodeToString(yamlContent.toByteArray(), Base64.NO_WRAP)
        executeWorkflowUpload(pat, owner, repo, base64Content, autoTrigger)
    }

    private suspend fun executeWorkflowUpload(pat: String, owner: String, repo: String, base64Content: String, autoTrigger: Boolean) {
        if (!autoTrigger) _workflowSetupState.value = "setup_started"
        val auth = "Bearer $pat"
        val path = ".github/workflows/build.yml"
        
        var sha: String? = null
        try {
            val getRes = RetrofitClient.api.getFileContent(auth, owner, repo, path)
            if (getRes.isSuccessful) {
                sha = getRes.body()?.content?.sha
            }
        } catch(e: Exception) {}
        
        val request = GithubContentRequest("Setup Android CI workflow", base64Content, sha)
        try {
            val res = RetrofitClient.api.updateFileContent(auth, owner, repo, path, request)
            if (!autoTrigger) {
                if (res.isSuccessful) {
                    _workflowSetupState.value = "setup_success"
                } else {
                    val errBody = res.errorBody()?.string() ?: "Unknown error"
                    val isWorkflowScopeMissing = errBody.contains("workflow scope", ignoreCase = true)
                    val errorMsg = if (isWorkflowScopeMissing) "Missing 'workflow' scope in PAT" else errBody
                    _workflowSetupState.value = "setup_failed:$errorMsg"
                }
            }
        } catch (e: Exception) {
            if (!autoTrigger) _workflowSetupState.value = "setup_failed:${e.message}"
        }
    }

    fun saveConfig(pat: String, owner: String, repo: String) {
        viewModelScope.launch {
            dataStore.saveConfig(pat, owner, repo)
        }
    }

    fun uploadZipFile(uri: Uri, uniqueId: String = UUID.randomUUID().toString().take(8)) {
        viewModelScope.launch {
            _uploadState.value = UploadState.Compressing
            
            val pat = patFlow.first() ?: return@launch
            val owner = ownerFlow.first() ?: return@launch
            val repo = repoFlow.first() ?: return@launch
            val auth = "Bearer $pat"
            
            try {
                val context = getApplication<Application>().applicationContext
                val inputStream = context.contentResolver.openInputStream(uri)
                if (inputStream == null) {
                    _uploadState.value = UploadState.Error("Failed to open file")
                    return@launch
                }
                
                // Add unique ID file to the zip
                val modifiedBytes = appendUniqueIdToZip(inputStream, uniqueId)
                
                // Read and base64 encode
                val base64Content = Base64.encodeToString(modifiedBytes, Base64.NO_WRAP)
                
                _uploadState.value = UploadState.Uploading
                
                val path = "project.zip"
                
                // Get current SHA if exists
                var sha: String? = null
                try {
                    val getResponse = RetrofitClient.api.getFileContent(auth, owner, repo, path)
                    if (getResponse.isSuccessful) {
                        sha = getResponse.body()?.content?.sha
                    }
                } catch (e: Exception) {
                    // Ignore, file might not exist
                }
                
                val message = "Upload project.zip [ID: $uniqueId]"
                
                val request = GithubContentRequest(message, base64Content, sha)
                val putResponse = RetrofitClient.api.updateFileContent(auth, owner, repo, path, request)
                
                if (putResponse.isSuccessful) {
                    _uploadState.value = UploadState.Success(putResponse.body()?.content?.sha ?: "")
                    startPolling()
                } else {
                    _uploadState.value = UploadState.Error("Upload failed: ${putResponse.errorBody()?.string()}")
                }
            } catch (e: Exception) {
                _uploadState.value = UploadState.Error("Exception: ${e.message}")
            }
        }
    }
    
    private var isPolling = false
    
    fun startPolling() {
        if (isPolling) return
        isPolling = true
        viewModelScope.launch {
            while (isPolling) {
                pollRuns()
                delay(3000)
            }
        }
    }
    
    fun stopPolling() {
        isPolling = false
    }
    
    private suspend fun pollRuns() {
        val pat = patFlow.first() ?: return
        val owner = ownerFlow.first() ?: return
        val repo = repoFlow.first() ?: return
        val auth = "Bearer $pat"
        
        try {
            val response = RetrofitClient.api.getWorkflowRuns(auth, owner, repo)
            if (response.isSuccessful) {
                _runs.value = response.body()?.workflowRuns ?: emptyList()
                _pollingError.value = null
            } else {
                _pollingError.value = "Failed to fetch runs: ${response.code()}"
            }
        } catch (e: Exception) {
            _pollingError.value = "Error fetching runs: ${e.message}"
        }
    }
    
    fun fetchLogs(runId: Long) {
        viewModelScope.launch {
            val pat = patFlow.first() ?: return@launch
            val owner = ownerFlow.first() ?: return@launch
            val repo = repoFlow.first() ?: return@launch
            val auth = "Bearer $pat"
            
            try {
                // The logs endpoint usually returns a redirect (302) to a zip file.
                // Retrofit/OkHttp handles the redirect automatically, so we get the zip as ResponseBody.
                val response = RetrofitClient.api.getWorkflowRunLogs(auth, owner, repo, runId)
                if (response.isSuccessful) {
                    val body = response.body()
                    if (body != null) {
                        _logs.value = "Downloaded logs archive (${body.contentLength()} bytes)."
                        // Note: Unzipping logs here is complex as it contains multiple files per job.
                        // We will just indicate that it was downloaded. 
                    } else {
                        _logs.value = "Empty logs response."
                    }
                } else {
                    _logs.value = "Logs not available yet or error: ${response.code()}"
                }
            } catch (e: Exception) {
                _logs.value = "Error fetching logs: ${e.message}"
            }
        }
    }

    suspend fun downloadArtifact(runId: Long): String {
        val pat = patFlow.first() ?: throw Exception("No PAT")
        val owner = ownerFlow.first() ?: throw Exception("No owner")
        val repo = repoFlow.first() ?: throw Exception("No repo")
        val auth = "Bearer $pat"
        
        val artifactsResponse = RetrofitClient.api.getWorkflowRunArtifacts(auth, owner, repo, runId)
        if (!artifactsResponse.isSuccessful) throw Exception("Failed to list artifacts")
        
        val artifacts = artifactsResponse.body()?.artifacts ?: emptyList()
        val apkArtifact = artifacts.firstOrNull { it.name.contains("apk", ignoreCase = true) } 
                          ?: artifacts.firstOrNull() 
                          ?: throw Exception("No artifacts found")
                          
        val downloadResponse = RetrofitClient.api.downloadArtifact(auth, apkArtifact.archive_download_url)
        if (!downloadResponse.isSuccessful) throw Exception("Failed to download artifact")
        
        val context = getApplication<Application>().applicationContext
        val file = File(context.getExternalFilesDir(null), "${apkArtifact.name}.zip")
        
        downloadResponse.body()?.byteStream()?.use { inputStream ->
            FileOutputStream(file).use { outputStream ->
                inputStream.copyTo(outputStream)
            }
        }
        
        return file.absolutePath
    }

    private fun appendUniqueIdToZip(inputStream: InputStream, uniqueId: String): ByteArray {
        val baos = ByteArrayOutputStream()
        val zos = java.util.zip.ZipOutputStream(baos)
        val zis = java.util.zip.ZipInputStream(inputStream)
        try {
            var entry = zis.nextEntry
            while (entry != null) {
                val newEntry = java.util.zip.ZipEntry(entry.name)
                zos.putNextEntry(newEntry)
                zis.copyTo(zos)
                zos.closeEntry()
                entry = zis.nextEntry
            }
            // Add unique file
            val uniqueEntry = java.util.zip.ZipEntry("build_id.txt")
            zos.putNextEntry(uniqueEntry)
            zos.write(uniqueId.toByteArray())
            zos.closeEntry()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            zis.close()
            zos.close()
        }
        return baos.toByteArray()
    }
}
