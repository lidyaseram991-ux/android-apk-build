package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.BudgetEntity
import com.example.data.BudgetRepository
import com.example.data.ExpenseEntity
import com.example.notifications.NotificationHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

data class BudgetUiState(
    val initialBudget: Double = 0.0,
    val totalSpent: Double = 0.0,
    val remainingBalance: Double = 0.0,
    val expenses: List<ExpenseEntity> = emptyList(),
    val dailyBurnRate: Double = 0.0,
    val weeklyBurnRate: Double = 0.0,
    val runwayDays: Int? = null, // null means infinite
    val runwayWeeks: Int? = null,
    val runwayMonths: Int? = null,
    val recommendedDailyLimit: Double = 0.0,
    val isWarning: Boolean = false,
    val isCritical: Boolean = false,
    val daysLeftInMonth: Long = 0,
    val appTheme: String = "default",
    val isEnglish: Boolean = false
)

class BudgetViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: BudgetRepository
    private val notificationHelper: NotificationHelper
    private val sharedPrefs: SharedPreferences = application.getSharedPreferences("budget_prefs", Context.MODE_PRIVATE)
    private val _appTheme = MutableStateFlow(sharedPrefs.getString("app_theme", "default") ?: "default")
    private val _isEnglish = MutableStateFlow(sharedPrefs.getBoolean("is_english", false))
    private val _customEndDate = MutableStateFlow(sharedPrefs.getLong("budget_end_date", 0L))

    init {
        val db = AppDatabase.getDatabase(application)
        repository = BudgetRepository(db.expensesDao(), db.budgetDao())
        notificationHelper = NotificationHelper(application)
    }

    private val _expensesFlow = repository.allExpenses
    private val _budgetFlow = repository.currentBudget

    val uiState: StateFlow<BudgetUiState> = combine(_expensesFlow, _budgetFlow, _appTheme, _isEnglish, _customEndDate) { expenses, budget, theme, isEn, customEnd ->
        calculateUiState(expenses, budget, theme, isEn, customEnd)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = BudgetUiState()
    )

    private fun calculateUiState(expenses: List<ExpenseEntity>, budget: BudgetEntity?, theme: String, isEnglish: Boolean, customEnd: Long): BudgetUiState {
        val initialBudget = budget?.initialBudget ?: 0.0
        val totalSpent = expenses.sumOf { it.price }
        val remainingBalance = initialBudget - totalSpent

        val today = LocalDate.now()
        val firstExpenseDate = expenses.minByOrNull { it.date }?.date ?: today
        val daysSinceFirstExpense = maxOf(1L, ChronoUnit.DAYS.between(firstExpenseDate, today) + 1)
        
        val dailyBurnRate = if (totalSpent > 0) totalSpent / daysSinceFirstExpense else 0.0
        val weeklyBurnRate = dailyBurnRate * 7

        var runwayDays: Int? = null
        var runwayWeeks: Int? = null
        var runwayMonths: Int? = null

        if (dailyBurnRate > 0) {
            val exactDays = remainingBalance / dailyBurnRate
            runwayDays = maxOf(0, exactDays.toInt())
            runwayWeeks = runwayDays / 7
            runwayMonths = runwayDays / 30
        }

        val endDate = if (customEnd > 0L) {
            val customDate = LocalDate.ofEpochDay(customEnd)
            if (customDate.isBefore(today)) today.plusDays(1) else customDate
        } else {
            YearMonth.from(today).atEndOfMonth()
        }
        var daysLeftInMonth = ChronoUnit.DAYS.between(today, endDate)
        if (daysLeftInMonth <= 0) daysLeftInMonth = 1

        val recommendedDailyLimit = maxOf(0.0, remainingBalance / daysLeftInMonth)

        val isWarning = remainingBalance < (initialBudget * 0.5) && remainingBalance >= (initialBudget * 0.2)
        val isCritical = remainingBalance < (initialBudget * 0.2) || (runwayDays != null && runwayDays <= 5)

        return BudgetUiState(
            initialBudget = initialBudget,
            totalSpent = totalSpent,
            remainingBalance = remainingBalance,
            expenses = expenses,
            dailyBurnRate = dailyBurnRate,
            weeklyBurnRate = weeklyBurnRate,
            runwayDays = runwayDays,
            runwayWeeks = runwayWeeks,
            runwayMonths = runwayMonths,
            recommendedDailyLimit = recommendedDailyLimit,
            isWarning = isWarning,
            isCritical = isCritical,
            daysLeftInMonth = daysLeftInMonth,
            appTheme = theme,
            isEnglish = isEnglish
        )
    }
    fun updateTheme(theme: String) {
        sharedPrefs.edit().putString("app_theme", theme).apply()
        _appTheme.value = theme
    }

    fun setCustomDaysRemaining(days: Int) {
        val newEndDate = LocalDate.now().plusDays(days.toLong())
        val epochDays = newEndDate.toEpochDay()
        sharedPrefs.edit().putLong("budget_end_date", epochDays).apply()
        _customEndDate.value = epochDays
    }
    
    fun toggleLanguage() {
        val newState = !_isEnglish.value
        sharedPrefs.edit().putBoolean("is_english", newState).apply()
        _isEnglish.value = newState
    }

    
    fun exportBackup(context: Context) {
        viewModelScope.launch {
            val state = uiState.first()
            val json = org.json.JSONObject()
            json.put("masroofi_backup", true)
            json.put("version", 1)
            json.put("initialBudget", state.initialBudget)
            json.put("appTheme", state.appTheme)
            
            val expensesArray = org.json.JSONArray()
            state.expenses.forEach { exp ->
                val expJson = org.json.JSONObject()
                expJson.put("name", exp.name)
                expJson.put("price", exp.price)
                expJson.put("date", exp.date.toString())
                expJson.put("time", exp.time.toString())
                expJson.put("category", exp.category)
                expensesArray.put(expJson)
            }
            json.put("expenses", expensesArray)
            
            val jsonString = json.toString(4)
            
            val file = java.io.File(context.cacheDir, "masroofi_backup.json")
            java.io.FileWriter(file).use { it.write(jsonString) }
            
            val uri = androidx.core.content.FileProvider.getUriForFile(
                context, 
                context.packageName + ".fileprovider",
                file
            )
            
            val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(android.content.Intent.createChooser(intent, if (state.isEnglish) "Share Backup" else "مشاركة النسخة الاحتياطية").apply {
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        }
    }

    fun importBackup(context: Context, uri: Uri) {
        viewModelScope.launch {
            try {
                val content = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                if (content != null) {
                    val json = org.json.JSONObject(content)
                    if (json.has("masroofi_backup") && json.getBoolean("masroofi_backup")) {
                        val initialBudget = json.getDouble("initialBudget")
                        val appTheme = json.getString("appTheme")
                        
                        repository.updateBudget(initialBudget)
                        updateTheme(appTheme)
                        
                        repository.deleteAllExpenses()
                        
                        val expensesArray = json.getJSONArray("expenses")
                        for (i in 0 until expensesArray.length()) {
                            val expJson = expensesArray.getJSONObject(i)
                            val exp = com.example.data.ExpenseEntity(
                                name = expJson.getString("name"),
                                price = expJson.getDouble("price"),
                                date = java.time.LocalDate.parse(expJson.getString("date")),
                                time = java.time.LocalTime.parse(expJson.getString("time")),
                                category = expJson.getString("category")
                            )
                            repository.insertExpense(exp)
                        }
                        
                        android.widget.Toast.makeText(context, if (_isEnglish.value) "Backup Imported Successfully" else "تم استيراد النسخة الاحتياطية بنجاح", android.widget.Toast.LENGTH_LONG).show()
                    } else {
                        android.widget.Toast.makeText(context, if (_isEnglish.value) "Invalid Backup File" else "ملف غير صالح", android.widget.Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                android.widget.Toast.makeText(context, if (_isEnglish.value) "Error importing backup" else "حدث خطأ أثناء الاستيراد", android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }

    fun saveCustomBackgroundImage(uri: Uri, context: Context) {
        viewModelScope.launch {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val file = File(context.filesDir, "custom_background.jpg")
                val outputStream = FileOutputStream(file)
                inputStream?.copyTo(outputStream)
                inputStream?.close()
                outputStream.close()
                
                updateTheme(file.absolutePath)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun addExpense(name: String, price: Double, date: LocalDate, time: java.time.LocalTime, category: String) {
        viewModelScope.launch {
            val expense = ExpenseEntity(name = name, price = price, date = date, time = time, category = category)
            repository.insertExpense(expense)
            checkAndNotifyCriticalState()
        }
    }

    fun deleteExpense(expense: ExpenseEntity) {
        viewModelScope.launch {
            repository.deleteExpenseById(expense.id)
        }
    }

    fun updateInitialBudget(amount: Double) {
        viewModelScope.launch {
            repository.updateBudget(amount)
        }
    }

    fun addFundsToBudget(amount: Double) {
        viewModelScope.launch {
            val currentBudget = _budgetFlow.first()?.initialBudget ?: 0.0
            repository.updateBudget(currentBudget + amount)
        }
    }

    private fun checkAndNotifyCriticalState() {
        viewModelScope.launch {
            val state = combine(_expensesFlow, _budgetFlow, _appTheme, _isEnglish, _customEndDate) { exp, budg, theme, isEn, customEnd -> 
                calculateUiState(exp, budg, theme, isEn, customEnd) 
            }.first()

            if (state.isCritical) {
                notificationHelper.showCriticalAlertNotification(
                    title = if (state.isEnglish) "Critical Budget Alert!" else "تنبيه حرج للميزانية!",
                    message = if (state.isEnglish) "Your balance is critically low. Please review your expenses." else "رصيدك انخفض بشكل حرج. يرجى مراجعة نفقاتك."
                )
            }
        }
    }
}
