package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.BudgetEntity
import com.example.data.BudgetRepository
import com.example.data.ExpenseEntity
import com.example.notifications.NotificationHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

data class BudgetUiState(
    val initialBudget: Double = 0.0,
    val totalSpent: Double = 0.0,
    val remainingBalance: Double = 0.0,
    val expenses: List<ExpenseEntity> = emptyList(),
    val dailyBurnRate: Double = 0.0,
    val weeklyBurnRate: Double = 0.0,
    val runwayDays: Int? = null, // null means infinite
    val runwayWeeks: Int? = null,
    val runwayMonths: Int? = null,
    val recommendedDailyLimit: Double = 0.0,
    val isWarning: Boolean = false,
    val isCritical: Boolean = false,
    val daysLeftInMonth: Long = 0,
    val appTheme: String = "default"
)

class BudgetViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: BudgetRepository
    private val notificationHelper: NotificationHelper
    private val sharedPrefs: SharedPreferences = application.getSharedPreferences("budget_prefs", Context.MODE_PRIVATE)
    private val _appTheme = MutableStateFlow(sharedPrefs.getString("app_theme", "default") ?: "default")

    init {
        val db = AppDatabase.getDatabase(application)
        repository = BudgetRepository(db.expensesDao(), db.budgetDao())
        notificationHelper = NotificationHelper(application)
    }

    private val _expensesFlow = repository.allExpenses
    private val _budgetFlow = repository.currentBudget

    val uiState: StateFlow<BudgetUiState> = combine(_expensesFlow, _budgetFlow, _appTheme) { expenses, budget, theme ->
        calculateUiState(expenses, budget, theme)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = BudgetUiState()
    )

    private fun calculateUiState(expenses: List<ExpenseEntity>, budget: BudgetEntity?, theme: String): BudgetUiState {
        val initialBudget = budget?.initialBudget ?: 0.0
        val totalSpent = expenses.sumOf { it.price }
        val remainingBalance = initialBudget - totalSpent

        val today = LocalDate.now()
        val firstExpenseDate = expenses.minByOrNull { it.date }?.date ?: today
        val daysSinceFirstExpense = maxOf(1L, ChronoUnit.DAYS.between(firstExpenseDate, today) + 1)
        
        val dailyBurnRate = if (totalSpent > 0) totalSpent / daysSinceFirstExpense else 0.0
        val weeklyBurnRate = dailyBurnRate * 7

        var runwayDays: Int? = null
        var runwayWeeks: Int? = null
        var runwayMonths: Int? = null

        if (dailyBurnRate > 0) {
            val exactDays = remainingBalance / dailyBurnRate
            runwayDays = maxOf(0, exactDays.toInt())
            runwayWeeks = runwayDays / 7
            runwayMonths = runwayDays / 30
        }

        val yearMonth = YearMonth.from(today)
        val lastDayOfMonth = yearMonth.atEndOfMonth()
        var daysLeftInMonth = ChronoUnit.DAYS.between(today, lastDayOfMonth)
        if (daysLeftInMonth <= 0) daysLeftInMonth = 1

        val recommendedDailyLimit = maxOf(0.0, remainingBalance / daysLeftInMonth)

        val isWarning = remainingBalance < (initialBudget * 0.5) && remainingBalance >= (initialBudget * 0.2)
        val isCritical = remainingBalance < (initialBudget * 0.2) || (runwayDays != null && runwayDays <= 5)

        return BudgetUiState(
            initialBudget = initialBudget,
            totalSpent = totalSpent,
            remainingBalance = remainingBalance,
            expenses = expenses,
            dailyBurnRate = dailyBurnRate,
            weeklyBurnRate = weeklyBurnRate,
            runwayDays = runwayDays,
            runwayWeeks = runwayWeeks,
            runwayMonths = runwayMonths,
            recommendedDailyLimit = recommendedDailyLimit,
            isWarning = isWarning,
            isCritical = isCritical,
            daysLeftInMonth = daysLeftInMonth,
            appTheme = theme
        )
    }
    fun updateTheme(theme: String) {
        sharedPrefs.edit().putString("app_theme", theme).apply()
        _appTheme.value = theme
    }

    fun saveCustomBackgroundImage(uri: Uri, context: Context) {
        viewModelScope.launch {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val file = File(context.filesDir, "custom_background.jpg")
                val outputStream = FileOutputStream(file)
                inputStream?.copyTo(outputStream)
                inputStream?.close()
                outputStream.close()
                
                updateTheme(file.absolutePath)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun addExpense(name: String, price: Double, date: LocalDate, time: java.time.LocalTime, category: String) {
        viewModelScope.launch {
            val expense = ExpenseEntity(name = name, price = price, date = date, time = time, category = category)
            repository.insertExpense(expense)
            checkAndNotifyCriticalState()
        }
    }

    fun deleteExpense(expense: ExpenseEntity) {
        viewModelScope.launch {
            repository.deleteExpenseById(expense.id)
        }
    }

    fun updateInitialBudget(amount: Double) {
        viewModelScope.launch {
            repository.updateBudget(amount)
        }
    }

    fun addFundsToBudget(amount: Double) {
        viewModelScope.launch {
            val currentBudget = _budgetFlow.first()?.initialBudget ?: 0.0
            repository.updateBudget(currentBudget + amount)
        }
    }

    private fun checkAndNotifyCriticalState() {
        viewModelScope.launch {
            val state = combine(_expensesFlow, _budgetFlow, _appTheme) { exp, budg, theme -> 
                calculateUiState(exp, budg, theme) 
            }.first()

            if (state.isCritical) {
                notificationHelper.showCriticalAlertNotification(
                    title = "تنبيه حرج للميزانية!",
                    message = "رصيدك انخفض بشكل حرج. يرجى مراجعة نفقاتك."
                )
            }
        }
    }
}
