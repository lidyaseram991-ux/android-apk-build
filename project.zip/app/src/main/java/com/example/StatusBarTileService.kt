package com.example

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import kotlinx.coroutines.flow.update

class StatusBarTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        updateTile()
    }

    override fun onClick() {
        super.onClick()
        val isVisible = StatusBarSettings.settingsFlow.value.isOverlayVisible
        StatusBarSettings.toggleOverlay(!isVisible)
        updateTile()
    }

    private fun updateTile() {
        val tile = qsTile ?: return
        val isVisible = StatusBarSettings.settingsFlow.value.isOverlayVisible
        tile.state = if (isVisible) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = "Super Status Bar"
        tile.updateTile()
    }
}
