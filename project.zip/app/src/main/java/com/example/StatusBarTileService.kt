package com.example

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import kotlinx.coroutines.flow.update

class StatusBarTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        updateTile()
    }

    override fun onClick() {
        super.onClick()
        
        if (!StatusBarSettings.isAccessibilityServiceRunning) {
            // Service is completely stopped by the system, we cannot start it from here.
            // Prompt the user by launching the main activity to guide them to settings.
            val intent = android.content.Intent(this, MainActivity::class.java).apply {
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivityAndCollapse(intent)
            return
        }
        
        val isVisible = StatusBarSettings.settingsFlow.value.isOverlayVisible
        StatusBarSettings.toggleOverlay(!isVisible)
        updateTile()
    }

    private fun updateTile() {
        val tile = qsTile ?: return
        val isVisible = StatusBarSettings.settingsFlow.value.isOverlayVisible && StatusBarSettings.isAccessibilityServiceRunning
        tile.state = if (isVisible) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = "Super Status Bar"
        tile.updateTile()
    }
}
