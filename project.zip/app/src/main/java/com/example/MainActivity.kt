package com.example

import android.app.LocaleManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.LocaleList
import androidx.activity.ComponentActivity
import java.util.Locale
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.ConfigScreen
import com.example.ui.screens.MainViewModel
import com.example.ui.screens.RunsScreen
import com.example.ui.screens.UploadScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    val mainViewModel: MainViewModel = viewModel()

                    NavHost(navController = navController, startDestination = "config") {
                        composable("config") {
                            ConfigScreen(
                                viewModel = mainViewModel,
                                onNavigateToUpload = {
                                    navController.navigate("upload")
                                },
                                onToggleLanguage = { toggleLanguage(this@MainActivity) }
                            )
                        }
                        composable("upload") {
                            UploadScreen(
                                viewModel = mainViewModel,
                                onNavigateToRuns = {
                                    navController.navigate("runs")
                                },
                                onToggleLanguage = { toggleLanguage(this@MainActivity) }
                            )
                        }
                        composable("runs") {
                            RunsScreen(
                                viewModel = mainViewModel,
                                onBack = {
                                    navController.popBackStack()
                                },
                                onToggleLanguage = { toggleLanguage(this@MainActivity) }
                            )
                        }
                    }
                }
            }
        }
    }

    private fun toggleLanguage(context: Context) {
        val currentLocale = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            context.resources.configuration.locales.get(0).language
        } else {
            @Suppress("DEPRECATION")
            context.resources.configuration.locale.language
        }

        val newLocale = if (currentLocale.startsWith("ar")) "en" else "ar"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val localeManager = context.getSystemService(LocaleManager::class.java)
            localeManager.applicationLocales = LocaleList.forLanguageTags(newLocale)
        } else {
            val locale = Locale(newLocale)
            Locale.setDefault(locale)
            val config = context.resources.configuration
            config.setLocale(locale)
            @Suppress("DEPRECATION")
            context.resources.updateConfiguration(config, context.resources.displayMetrics)
            recreate()
        }
    }
}
