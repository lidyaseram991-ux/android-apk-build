package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.ui.theme.MyApplicationTheme
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.runtime.CompositionLocalProvider

@Composable
fun T(en: String, ar: String): String {
    val state by StatusBarSettings.settingsFlow.collectAsState()
    return if (state.language == "ar") ar else en
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val state by StatusBarSettings.settingsFlow.collectAsState()
            val layoutDirection = if (state.language == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr
            
            CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
                MyApplicationTheme {
                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        topBar = {
                            @OptIn(ExperimentalMaterial3Api::class)
                            TopAppBar(
                                title = { Text(T("Super Status Bar", "شريط الحالة المخصص")) },
                                colors = TopAppBarDefaults.topAppBarColors(
                                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                )
                            )
                        }
                    ) { innerPadding ->
                        ControlDashboard(modifier = Modifier.padding(innerPadding))
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ControlDashboard(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val state by StatusBarSettings.settingsFlow.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(text = T("Permissions Required", "الأذونات المطلوبة"), style = MaterialTheme.typography.titleLarge)
        
        Button(
            onClick = {
                if (!Settings.canDrawOverlays(context)) {
                    context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(T("Enable Overlay Permission", "تفعيل إذن الظهور فوق التطبيقات"))
        }
        
        Button(
            onClick = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(T("Enable Accessibility Service", "تفعيل خدمة إمكانية الوصول"))
        }

        Button(
            onClick = { context.startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(T("Enable Notification Access", "تفعيل إذن الوصول للإشعارات"))
        }

        Spacer(modifier = Modifier.height(16.dp))
        
        Text(text = T("Dashboard Settings", "إعدادات لوحة التحكم"), style = MaterialTheme.typography.titleLarge)
        
        // Background Alpha
        Text(T("Status Bar Transparency:", "شفافية شريط الحالة:") + " ${(state.backgroundAlpha * 100).toInt()}%")
        Slider(
            value = state.backgroundAlpha,
            onValueChange = { StatusBarSettings.updateBackgroundAlpha(it) },
            valueRange = 0f..1f,
            modifier = Modifier.fillMaxWidth()
        )
        
        // Battery Style
        var batteryStyleExpanded by remember { mutableStateOf(false) }
        ExposedDropdownMenuBox(
            expanded = batteryStyleExpanded,
            onExpandedChange = { batteryStyleExpanded = !batteryStyleExpanded }
        ) {
            OutlinedTextField(
                readOnly = true,
                value = state.batteryStyle.name,
                onValueChange = { },
                label = { Text(T("Battery Style", "شكل البطارية")) },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = batteryStyleExpanded) },
                colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
                modifier = Modifier.menuAnchor().fillMaxWidth()
            )
            ExposedDropdownMenu(
                expanded = batteryStyleExpanded,
                onDismissRequest = { batteryStyleExpanded = false }
            ) {
                BatteryStyle.values().forEach { style ->
                    DropdownMenuItem(
                        text = { Text(style.name) },
                        onClick = {
                            StatusBarSettings.updateBatteryStyle(style)
                            batteryStyleExpanded = false
                        }
                    )
                }
            }
        }
        
        // Battery
        Text(T("Mock Battery Percentage:", "نسبة البطارية الوهمية:") + " ${state.batteryPercentage}%")
        Slider(
            value = state.batteryPercentage.toFloat(),
            onValueChange = { StatusBarSettings.updateBattery(it.toInt()) },
            valueRange = 0f..100f,
            modifier = Modifier.fillMaxWidth()
        )
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Text(T("Show percentage inside battery", "عرض النسبة داخل البطارية"))
            androidx.compose.material3.Switch(
                checked = state.isPercentageInside,
                onCheckedChange = { StatusBarSettings.updatePercentageInside(it) }
            )
        }
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Text(T("Show battery on the right", "عرض البطارية في الجهة اليمنى"))
            androidx.compose.material3.Switch(
                checked = state.isBatteryOnRight,
                onCheckedChange = { StatusBarSettings.updateBatteryPosition(it) }
            )
        }

        // Auto Charge
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Text(T("Auto-charge Battery", "شحن تلقائي للبطارية"))
            androidx.compose.material3.Switch(
                checked = state.isAutoCharging,
                onCheckedChange = { StatusBarSettings.toggleAutoCharging(it) }
            )
        }
        
        if (state.isAutoCharging) {
            Text(T("Auto-charge interval:", "المدة الزمنية للشحن التلقائي:") + " ${state.autoChargeIntervalSeconds}s")
            Slider(
                value = state.autoChargeIntervalSeconds.toFloat(),
                onValueChange = { StatusBarSettings.updateAutoChargeInterval(it.toInt()) },
                valueRange = 1f..60f,
                modifier = Modifier.fillMaxWidth()
            )
        }
        
        // Icons
        Text(text = T("Icons", "الأيقونات"), style = MaterialTheme.typography.titleMedium)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text(T("Bluetooth", "بلوتوث"))
            androidx.compose.material3.Switch(checked = state.showBluetooth, onCheckedChange = { StatusBarSettings.updateToggles(bluetooth = it) })
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text(T("WiFi", "واي فاي"))
            androidx.compose.material3.Switch(checked = state.showWifi, onCheckedChange = { StatusBarSettings.updateToggles(wifi = it) })
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text(T("Alarm", "المنبه"))
            androidx.compose.material3.Switch(checked = state.showAlarm, onCheckedChange = { StatusBarSettings.updateToggles(alarm = it) })
        }

        // Network
        Text(text = T("Network", "الشبكة"), style = MaterialTheme.typography.titleMedium)
        Text(T("Signal Strength:", "قوة الإشارة:") + " ${state.networkStrength}")
        Slider(
            value = state.networkStrength.toFloat(),
            onValueChange = { StatusBarSettings.updateNetwork(strength = it.toInt()) },
            valueRange = 0f..4f,
            steps = 3,
            modifier = Modifier.fillMaxWidth()
        )
        
        val options = listOf("4G", "5G", "H+", "LTE")
        var expanded by remember { mutableStateOf(false) }
        
        ExposedDropdownMenuBox(
            expanded = expanded,
            onExpandedChange = { expanded = !expanded }
        ) {
            OutlinedTextField(
                readOnly = true,
                value = state.networkType,
                onValueChange = { },
                label = { Text(T("Network Type", "نوع الشبكة")) },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
                modifier = Modifier.menuAnchor().fillMaxWidth()
            )
            ExposedDropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                options.forEach { selectionOption ->
                    DropdownMenuItem(
                        text = { Text(selectionOption) },
                        onClick = {
                            StatusBarSettings.updateNetwork(type = selectionOption)
                            expanded = false
                        }
                    )
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Button(
            onClick = { StatusBarSettings.toggleLanguage() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (state.language == "ar") "Switch to English" else "تغيير اللغة إلى العربية")
        }
        
        Text(
            text = T("App Developer: Mustafeen Omar", "مطور التطبيق: مصطفين عمر"),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(vertical = 16.dp)
        )
        
        Spacer(modifier = Modifier.height(32.dp))
    }
}
