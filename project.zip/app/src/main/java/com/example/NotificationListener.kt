package com.example

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PorterDuff
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import androidx.core.graphics.drawable.toBitmap

class NotificationListener : NotificationListenerService() {
    
    override fun onListenerConnected() {
        super.onListenerConnected()
        updateIcons()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        updateIcons()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        updateIcons()
    }

    private fun updateIcons() {
        try {
            val currentNotifications = activeNotifications ?: return
            
            // Group by package to avoid too many duplicate icons (like 10 messages from WhatsApp)
            // Or just take the distinct small icons. Let's just group by package name for simplicity.
            val distinctNotifications = currentNotifications
                .distinctBy { it.packageName }
                .take(5)
            
            val size = (14 * resources.displayMetrics.density).toInt() // 14dp icon size
            
            val bitmaps = distinctNotifications.mapNotNull { sbn ->
                try {
                    val icon = sbn.notification.smallIcon ?: return@mapNotNull null
                    
                    // Prevent framework from logging an error if the resource package is missing
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                        if (icon.type == android.graphics.drawable.Icon.TYPE_RESOURCE) {
                            val resPkg = icon.resPackage
                            if (!resPkg.isNullOrEmpty()) {
                                try {
                                    packageManager.getApplicationInfo(resPkg, 0)
                                } catch (e: android.content.pm.PackageManager.NameNotFoundException) {
                                    return@mapNotNull null // Package not found, skip to avoid Icon log error
                                }
                            }
                        }
                    }
                    
                    val drawable = icon.loadDrawable(this) ?: return@mapNotNull null
                    
                    // We want the icon to be white for the status bar
                    drawable.mutate().setTint(Color.WHITE)
                    drawable.mutate().setTintMode(PorterDuff.Mode.SRC_ATOP)
                    
                    drawable.toBitmap(width = size, height = size, config = Bitmap.Config.ARGB_8888)
                } catch (e: Exception) {
                    null
                }
            }
            
            StatusBarSettings.updateNotificationIcons(bitmaps)
        } catch (e: Exception) {
            Log.e("NotificationListener", "Error updating icons", e)
        }
    }
}
