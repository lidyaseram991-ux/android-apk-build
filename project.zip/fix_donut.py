import os

file_path = "app/src/main/java/com/example/ui/ReportsScreen.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Fix donut chart sizing dynamically
old_draw = """                        drawArc(
                            color = colors[i % colors.size],
                            startAngle = startAngle,
                            sweepAngle = sweepAngle,
                            useCenter = false,
                            topLeft = Offset(40f, 40f),
                            size = Size(size.width - 80f, size.height - 80f),
                            style = Stroke(width = 40.dp.toPx())
                        )"""

new_draw = """                        val strokeWidth = 32.dp.toPx()
                        val halfStroke = strokeWidth / 2
                        drawArc(
                            color = colors[i % colors.size],
                            startAngle = startAngle,
                            sweepAngle = sweepAngle,
                            useCenter = false,
                            topLeft = Offset(halfStroke, halfStroke),
                            size = Size(size.width - strokeWidth, size.height - strokeWidth),
                            style = Stroke(width = strokeWidth)
                        )"""

content = content.replace(old_draw, new_draw)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed donut sizing.")
