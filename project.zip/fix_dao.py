import os

file_path = "app/src/main/java/com/example/data/ExpensesDao.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

content = content.replace(
    'suspend fun deleteExpenseById(id: Int)',
    'suspend fun deleteExpenseById(id: Int)\n\n    @Query("DELETE FROM expenses")\n    suspend fun deleteAllExpenses()'
)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Updated DAO.")
