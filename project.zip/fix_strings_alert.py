import os

file_path = "app/src/main/java/com/example/ui/AppStrings.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

en_adds = """        "reset_days" to "Reset to Calendar Month End",
        "warning_title" to "Warning!",
        "critical_title" to "Critical Alert!",
        "warning_desc" to "Your balance is below 50% of original budget.",
        "critical_desc" to "Your balance is below 20% or lasts for less than 5 days.",
        "close" to "Close"
"""
content = content.replace(
    '"reset_days" to "Reset to Calendar Month End"\n    )',
    en_adds + '    )'
)

ar_adds = """        "reset_days" to "إعادة للافتراضي (نهاية الشهر الحالي)",
        "warning_title" to "تحذير!",
        "critical_title" to "حالة حرجة!",
        "warning_desc" to "رصيدك أقل من 50% من الميزانية.",
        "critical_desc" to "رصيدك أقل من 20% أو يكفيك لأقل من 5 أيام.",
        "close" to "إغلاق"
"""
content = content.replace(
    '"reset_days" to "إعادة للافتراضي (نهاية الشهر الحالي)"\n    )',
    ar_adds + '    )'
)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed strings alert.")
