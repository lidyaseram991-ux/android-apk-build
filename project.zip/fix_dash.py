import os

file_path = "app/src/main/java/com/example/ui/DashboardScreen.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

content = content.replace(
    'Text("المبلغ المتبقي يكفيك لمدة:", fontWeight = FontWeight.SemiBold)',
    'Text(string("runway_duration"), fontWeight = FontWeight.SemiBold)'
)
content = content.replace(
    'Text("${uiState.runwayDays} يوم / ${uiState.runwayWeeks} أسبوع / ${uiState.runwayMonths} شهر")',
    'Text("${uiState.runwayDays} ${string("day_unit")} / ${uiState.runwayWeeks} ${string("week_unit")} / ${uiState.runwayMonths} ${string("month_unit")}")'
)
content = content.replace(
    'Text("✅ ممتاز! معدل إنفاقك الحالي يضمن بقاء الميزانية حتى نهاية الشهر.", color = Color(0xFF388E3C), style = MaterialTheme.typography.bodyMedium)',
    'Text(string("runway_good"), color = Color(0xFF388E3C), style = MaterialTheme.typography.bodyMedium)'
)
content = content.replace(
    'Text("⚠️ تنبيه: معدل إنفاقك مرتفع، الميزانية ستنفد قبل نهاية الشهر (${uiState.daysLeftInMonth} أيام متبقية).", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)',
    'Text("${string("runway_bad_prefix")}${uiState.daysLeftInMonth}${string("runway_bad_suffix")}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)'
)
content = content.replace(
    'Text("بيانات الاستهلاك غير كافية لحساب المدى.", color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.7f))',
    'Text(string("insufficient_data"), color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.7f))'
)
content = content.replace(
    'Text("معدل الحرق اليومي: ${numberFormat.format(uiState.dailyBurnRate)}")',
    'Text("${string("daily_burn_rate")}${numberFormat.format(uiState.dailyBurnRate)}")'
)
content = content.replace(
    'Text("معدل الحرق الأسبوعي: ${numberFormat.format(uiState.weeklyBurnRate)}")',
    'Text("${string("weekly_burn_rate")}${numberFormat.format(uiState.weeklyBurnRate)}")'
)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed dashboard.")
