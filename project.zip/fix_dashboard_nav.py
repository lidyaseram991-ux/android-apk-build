import os

file_path = "app/src/main/java/com/example/ui/DashboardScreen.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Remove the TopAppBar actions
actions_block = """                actions = {
                    IconButton(onClick = { navController.navigate(Routes.HISTORY) }) {
                        Icon(Icons.AutoMirrored.Filled.List, contentDescription = "السجل")
                    }
                    IconButton(onClick = { navController.navigate(Routes.BUDGET_CONFIG) }) {
                        Icon(Icons.Default.Settings, contentDescription = "الإعدادات")
                    }
                }"""
content = content.replace(actions_block, "")

actions_block_fallback = """                actions = {
                    IconButton(onClick = { navController.navigate(Routes.HISTORY) }) {
                        Icon(Icons.Default.List, contentDescription = "السجل")
                    }
                    IconButton(onClick = { navController.navigate(Routes.BUDGET_CONFIG) }) {
                        Icon(Icons.Default.Settings, contentDescription = "الإعدادات")
                    }
                }"""
content = content.replace(actions_block_fallback, "")

# Remove the FloatingActionButton
fab_block = """        floatingActionButton = {
            FloatingActionButton(
                onClick = { navController.navigate(Routes.ADD_EXPENSE) },
                modifier = Modifier.testTag("add_expense_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة مصروف")
            }
        }"""
content = content.replace(fab_block, "")

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Dashboard nav cleaned.")
