import os

file_path = "app/src/main/java/com/example/ui/Navigation.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

content = content.replace(
    'modifier = Modifier.padding(paddingValues)',
    'modifier = Modifier.padding(bottom = paddingValues.calculateBottomPadding())'
)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed Scaffold padding.")
