import os

file_path = "app/src/main/java/com/example/ui/BudgetViewModel.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

content = content.replace(
    'val state = combine(_expensesFlow, _budgetFlow, _appTheme, _isEnglish) { exp, budg, theme, isEn -> \n                calculateUiState(exp, budg, theme, isEn) \n            }.first()',
    'val state = combine(_expensesFlow, _budgetFlow, _appTheme, _isEnglish, _customEndDate) { exp, budg, theme, isEn, customEnd -> \n                calculateUiState(exp, budg, theme, isEn, customEnd) \n            }.first()'
)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed critical state combine.")
