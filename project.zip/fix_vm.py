import os

file_path = "app/src/main/java/com/example/ui/BudgetViewModel.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

import_code = """
    fun exportBackup(context: Context) {
        viewModelScope.launch {
            val state = uiState.first()
            val json = org.json.JSONObject()
            json.put("masroofi_backup", true)
            json.put("version", 1)
            json.put("initialBudget", state.initialBudget)
            json.put("appTheme", state.appTheme)
            
            val expensesArray = org.json.JSONArray()
            state.expenses.forEach { exp ->
                val expJson = org.json.JSONObject()
                expJson.put("name", exp.name)
                expJson.put("price", exp.price)
                expJson.put("date", exp.date.toString())
                expJson.put("time", exp.time.toString())
                expJson.put("category", exp.category)
                expensesArray.put(expJson)
            }
            json.put("expenses", expensesArray)
            
            val jsonString = json.toString(4)
            
            val file = java.io.File(context.cacheDir, "masroofi_backup.json")
            java.io.FileWriter(file).use { it.write(jsonString) }
            
            val uri = androidx.core.content.FileProvider.getUriForFile(
                context, 
                context.packageName + ".provider",
                file
            )
            
            val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(android.content.Intent.createChooser(intent, if (state.isEnglish) "Share Backup" else "مشاركة النسخة الاحتياطية").apply {
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        }
    }

    fun importBackup(context: Context, uri: Uri) {
        viewModelScope.launch {
            try {
                val content = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                if (content != null) {
                    val json = org.json.JSONObject(content)
                    if (json.has("masroofi_backup") && json.getBoolean("masroofi_backup")) {
                        val initialBudget = json.getDouble("initialBudget")
                        val appTheme = json.getString("appTheme")
                        
                        repository.updateBudget(initialBudget)
                        setAppTheme(appTheme)
                        
                        repository.deleteAllExpenses()
                        
                        val expensesArray = json.getJSONArray("expenses")
                        for (i in 0 until expensesArray.length()) {
                            val expJson = expensesArray.getJSONObject(i)
                            val exp = com.example.data.ExpenseEntity(
                                name = expJson.getString("name"),
                                price = expJson.getDouble("price"),
                                date = java.time.LocalDate.parse(expJson.getString("date")),
                                time = java.time.LocalTime.parse(expJson.getString("time")),
                                category = expJson.getString("category")
                            )
                            repository.insertExpense(exp)
                        }
                        
                        android.widget.Toast.makeText(context, if (_isEnglish.value) "Backup Imported Successfully" else "تم استيراد النسخة الاحتياطية بنجاح", android.widget.Toast.LENGTH_LONG).show()
                    } else {
                        android.widget.Toast.makeText(context, if (_isEnglish.value) "Invalid Backup File" else "ملف غير صالح", android.widget.Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                android.widget.Toast.makeText(context, if (_isEnglish.value) "Error importing backup" else "حدث خطأ أثناء الاستيراد", android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }
"""

content = content.replace(
    'fun saveCustomBackgroundImage(uri: Uri, context: Context) {',
    import_code + '\n    fun saveCustomBackgroundImage(uri: Uri, context: Context) {'
)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Updated ViewModel.")
