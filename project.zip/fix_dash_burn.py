import os

file_path = "app/src/main/java/com/example/ui/DashboardScreen.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

content = content.replace(
    'Text("${string("")}${numberFormat.format(uiState.dailyBurnRate)}")',
    'Text("${string("daily_burn_rate")}: ${numberFormat.format(uiState.dailyBurnRate)}")'
)
content = content.replace(
    'Text("${string("")}${numberFormat.format(uiState.weeklyBurnRate)}")',
    'Text("${string("weekly_burn_rate")}: ${numberFormat.format(uiState.weeklyBurnRate)}")'
)
content = content.replace(
    'Text("${uiState.runwayDays} ${string("")} / ${uiState.runwayWeeks} ${string("")} / ${uiState.runwayMonths} ${string("")}")',
    'Text("${uiState.runwayDays} ${string("day_unit")} / ${uiState.runwayWeeks} ${string("week_unit")} / ${uiState.runwayMonths} ${string("month_unit")}")'
)
content = content.replace(
    'Text("${string("")}${uiState.daysLeftInMonth}${string("")}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)',
    'Text("${string("runway_bad_prefix")}${uiState.daysLeftInMonth}${string("runway_bad_suffix")}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)'
)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed dashboard burn rates.")
