import os

file_path = "app/src/main/java/com/example/ui/AppStrings.kt"

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

en_adds = """        "insufficient_data" to "Insufficient consumption data to calculate runway.",
        "budget_period" to "Budget Period",
        "days_remaining_setup" to "Days remaining for cycle end",
        "set_days" to "Set Days",
        "reset_days" to "Reset to Calendar Month End"
"""
content = content.replace(
    '"insufficient_data" to "Insufficient consumption data to calculate runway."\n    )',
    en_adds + '    )'
)

ar_adds = """        "insufficient_data" to "بيانات الاستهلاك غير كافية لحساب المدى.",
        "budget_period" to "فترة الميزانية",
        "days_remaining_setup" to "الأيام المتبقية لنهاية الدورة",
        "set_days" to "تعيين",
        "reset_days" to "إعادة للافتراضي (نهاية الشهر الحالي)"
"""
content = content.replace(
    '"insufficient_data" to "بيانات الاستهلاك غير كافية لحساب المدى."\n    )',
    ar_adds + '    )'
)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed strings.")
